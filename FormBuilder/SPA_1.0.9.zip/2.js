function onSalutationChange(value) {
    console.log("From 2.js - Value Passed - Key: ", value.key, "; Text: ", value.text);
    alert("From 2.js - Value Passed - Key: " + value.key + "; Text: " + value.text);

    return {
        values: [
            {
                key: "lastname",
                value: "Shagin"
            }
        ],
        messages: [
            {
                type: "info",
                message: "lastName values updated successfully"
            }
        ]
    }
}