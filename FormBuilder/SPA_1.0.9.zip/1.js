// Create namespace if it doesn't exist
if (typeof Cjs === 'undefined') {
    window.Cjs = {};
}
if (typeof Cjs.Events === 'undefined') {
    Cjs.Events = {};
}

// Define the function under the namespace
Cjs.Events.onSalutationChange = function(value) {
    console.log("Value Passed - Key: ", value.key, "; Text: ", value.text);
    alert("Value Passed - Key: " + value.key + "; Text: " + value.text);

    return {
        values: [
            {
                key: "firstname",
                value: "Samuel"
            },
            {
                key: "height",
                value: 180
            },
            {
                key: "weight",
                value: 93.5
            }
        ],
        messages: [
            {
                type: "info",
                message: "firstName values updated successfully"
            },
            {
                type: "info",
                message: "height values updated successfully"
            },
            {
                type: "info",
                message: "weight values updated successfully"
            }
        ]
    }
};