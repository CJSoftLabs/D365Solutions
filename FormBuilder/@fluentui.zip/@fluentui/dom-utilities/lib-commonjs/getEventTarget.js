"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEventTarget = void 0;
var getEventTarget = function (event) {
    var target = event.target;
    if (target && target.shadowRoot) {
        target = event.composedPath()[0];
    }
    return target;
};
exports.getEventTarget = getEventTarget;
//# sourceMappingURL=getEventTarget.js.map