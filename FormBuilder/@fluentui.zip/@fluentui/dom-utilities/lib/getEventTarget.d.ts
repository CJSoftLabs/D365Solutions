export declare const getEventTarget: (event: Event) => HTMLElement | null;
