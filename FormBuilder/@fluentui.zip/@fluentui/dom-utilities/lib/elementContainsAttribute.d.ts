/**
 * Determines if an element, or any of its ancestors, contain the given attribute
 * @param element - element to start searching at
 * @param attribute - the attribute to search for
 * @returns the value of the first instance found
 */
export declare function elementContainsAttribute(element: HTMLElement, attribute: string, doc?: Document): string | null;
