export declare const getActiveElement: (doc: Document) => Element | null;
