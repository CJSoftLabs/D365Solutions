define(["require", "exports", "./findElementRecursive", "./setPortalAttribute"], function (require, exports, findElementRecursive_1, setPortalAttribute_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.portalContainsElement = void 0;
    /**
     * Determine whether a target is within a portal from perspective of root or optional parent.
     * This function only works against portal components that use the setPortalAttribute function.
     * If both parent and child are within the same portal this function will return false.
     * @param target - Element to query portal containment status of.
     * @param parent - Optional parent perspective. Search for containing portal stops at parent
     * (or root if parent is undefined or invalid.)
     */
    function portalContainsElement(target, parent, doc) {
        var _a;
        var elementMatch = (0, findElementRecursive_1.findElementRecursive)(target, function (testElement) { var _a; return parent === testElement || !!((_a = testElement.hasAttribute) === null || _a === void 0 ? void 0 : _a.call(testElement, setPortalAttribute_1.DATA_PORTAL_ATTRIBUTE)); }, doc);
        return elementMatch !== null && !!((_a = elementMatch.hasAttribute) === null || _a === void 0 ? void 0 : _a.call(elementMatch, setPortalAttribute_1.DATA_PORTAL_ATTRIBUTE));
    }
    exports.portalContainsElement = portalContainsElement;
});
//# sourceMappingURL=portalContainsElement.js.map