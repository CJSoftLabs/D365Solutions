define(["require", "exports", "./getVirtualParent"], function (require, exports, getVirtualParent_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getParent = void 0;
    /**
     * Gets the element which is the parent of a given element.
     * If `allowVirtuaParents` is `true`, this method prefers the virtual parent over
     * real DOM parent when present.
     *
     * @public
     */
    function getParent(child, allowVirtualParents) {
        var _a, _b;
        if (allowVirtualParents === void 0) { allowVirtualParents = true; }
        if (!child) {
            return null;
        }
        var parent = allowVirtualParents && (0, getVirtualParent_1.getVirtualParent)(child);
        if (parent) {
            return parent;
        }
        // Support looking for parents in shadow DOM
        if (typeof child.assignedElements !== 'function' && ((_a = child.assignedSlot) === null || _a === void 0 ? void 0 : _a.parentNode)) {
            // Element is slotted
            return child.assignedSlot;
        }
        else if (((_b = child.parentNode) === null || _b === void 0 ? void 0 : _b.nodeType) === 11) {
            // nodeType 11 is DOCUMENT_FRAGMENT
            // Element is in shadow root
            return child.parentNode.host;
        }
        else {
            return child.parentNode;
        }
    }
    exports.getParent = getParent;
});
//# sourceMappingURL=getParent.js.map