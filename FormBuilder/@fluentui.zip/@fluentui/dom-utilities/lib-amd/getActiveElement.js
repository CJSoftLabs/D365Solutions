define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getActiveElement = void 0;
    var getActiveElement = function (doc) {
        var ae = doc.activeElement;
        while (ae === null || ae === void 0 ? void 0 : ae.shadowRoot) {
            ae = ae.shadowRoot.activeElement;
        }
        return ae;
    };
    exports.getActiveElement = getActiveElement;
});
//# sourceMappingURL=getActiveElement.js.map