define(["require", "exports", "./elementContains", "./elementContainsAttribute", "./findElementRecursive", "./getActiveElement", "./getChildren", "./getEventTarget", "./getParent", "./getVirtualParent", "./isVirtualElement", "./portalContainsElement", "./setPortalAttribute", "./setVirtualParent", "./version"], function (require, exports, elementContains_1, elementContainsAttribute_1, findElementRecursive_1, getActiveElement_1, getChildren_1, getEventTarget_1, getParent_1, getVirtualParent_1, isVirtualElement_1, portalContainsElement_1, setPortalAttribute_1, setVirtualParent_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.setVirtualParent = exports.setPortalAttribute = exports.DATA_PORTAL_ATTRIBUTE = exports.portalContainsElement = exports.isVirtualElement = exports.getVirtualParent = exports.getParent = exports.getEventTarget = exports.getChildren = exports.getActiveElement = exports.findElementRecursive = exports.elementContainsAttribute = exports.elementContains = void 0;
    Object.defineProperty(exports, "elementContains", { enumerable: true, get: function () { return elementContains_1.elementContains; } });
    Object.defineProperty(exports, "elementContainsAttribute", { enumerable: true, get: function () { return elementContainsAttribute_1.elementContainsAttribute; } });
    Object.defineProperty(exports, "findElementRecursive", { enumerable: true, get: function () { return findElementRecursive_1.findElementRecursive; } });
    Object.defineProperty(exports, "getActiveElement", { enumerable: true, get: function () { return getActiveElement_1.getActiveElement; } });
    Object.defineProperty(exports, "getChildren", { enumerable: true, get: function () { return getChildren_1.getChildren; } });
    Object.defineProperty(exports, "getEventTarget", { enumerable: true, get: function () { return getEventTarget_1.getEventTarget; } });
    Object.defineProperty(exports, "getParent", { enumerable: true, get: function () { return getParent_1.getParent; } });
    Object.defineProperty(exports, "getVirtualParent", { enumerable: true, get: function () { return getVirtualParent_1.getVirtualParent; } });
    Object.defineProperty(exports, "isVirtualElement", { enumerable: true, get: function () { return isVirtualElement_1.isVirtualElement; } });
    Object.defineProperty(exports, "portalContainsElement", { enumerable: true, get: function () { return portalContainsElement_1.portalContainsElement; } });
    Object.defineProperty(exports, "DATA_PORTAL_ATTRIBUTE", { enumerable: true, get: function () { return setPortalAttribute_1.DATA_PORTAL_ATTRIBUTE; } });
    Object.defineProperty(exports, "setPortalAttribute", { enumerable: true, get: function () { return setPortalAttribute_1.setPortalAttribute; } });
    Object.defineProperty(exports, "setVirtualParent", { enumerable: true, get: function () { return setVirtualParent_1.setVirtualParent; } });
});
//# sourceMappingURL=index.js.map