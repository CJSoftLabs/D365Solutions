import { IStyle } from './IStyle';
import { SHADOW_DOM_STYLESHEET_SETTING } from './shadowConfig';
import type { ShadowConfig } from './shadowConfig';
export declare const InjectionMode: {
    /**
     * Avoids style injection, use getRules() to read the styles.
     */
    none: 0;
    /**
     * Inserts rules using the insertRule api.
     */
    insertNode: 1;
    /**
     * Appends rules using appendChild.
     */
    appendChild: 2;
};
export type InjectionMode = (typeof InjectionMode)[keyof typeof InjectionMode];
/**
 * CSP settings for the stylesheet
 */
export interface ICSPSettings {
    /**
     * Nonce to inject into script tag
     */
    nonce?: string;
}
/**
 * Stylesheet config.
 *
 * @public
 */
export interface IStyleSheetConfig {
    /**
     * Injection mode for how rules are inserted.
     */
    injectionMode?: InjectionMode;
    /**
     * Default 'displayName' to use for a className.
     * @defaultvalue 'css'
     */
    defaultPrefix?: string;
    /**
     * Defines the default direction of rules for auto-rtlifying things.
     * While typically this is represented as a DIR attribute in the markup,
     * the DIR is not enough to control whether padding goes on the left or
     * right. Use this to set the default direction when rules are registered.
     */
    rtl?: boolean;
    /**
     * Default 'namespace' to attach before the className.
     */
    namespace?: string;
    /**
     * CSP settings
     */
    cspSettings?: ICSPSettings;
    /**
     * Callback executed when a rule is inserted.
     * @deprecated Use `Stylesheet.onInsertRule` instead.
     */
    onInsertRule?: (rule: string) => void;
    /**
     * Initial value for classnames cache. Key is serialized css rules associated with a classname.
     */
    classNameCache?: {
        [key: string]: string;
    };
    window?: Window;
    inShadow?: boolean;
    stylesheetKey?: string;
}
/**
 * Representation of Stylesheet used for rehydration.
 */
export interface ISerializedStylesheet {
    classNameToArgs: Stylesheet['_classNameToArgs'];
    counter: Stylesheet['_counter'];
    keyToClassName: Stylesheet['_keyToClassName'];
    preservedRules: Stylesheet['_preservedRules'];
    rules: Stylesheet['_rules'];
}
export declare const STYLESHEET_SETTING = "__stylesheet__";
declare global {
    interface Document {
        adoptedStyleSheets: CSSStyleSheet[];
    }
}
export type WindowWithMergeStyles = (Window | {}) & {
    [STYLESHEET_SETTING]?: Stylesheet;
    [SHADOW_DOM_STYLESHEET_SETTING]?: typeof Stylesheet;
    FabricConfig?: {
        mergeStyles?: IStyleSheetConfig;
        serializedStylesheet?: ISerializedStylesheet;
    };
};
export type ExtendedCSSStyleSheet = CSSStyleSheet & {
    bucketName: string;
    metadata: Record<string, unknown>;
};
type InsertRuleArgs = {
    key?: string;
    sheet?: ExtendedCSSStyleSheet | null;
    rule?: string;
};
export type InsertRuleCallback = ({ key, sheet, rule }: InsertRuleArgs) => void;
/**
 * Represents the state of styles registered in the page. Abstracts
 * the surface for adding styles to the stylesheet, exposes helpers
 * for reading the styles registered in server rendered scenarios.
 *
 * @public
 */
export declare class Stylesheet {
    protected _lastStyleElement?: HTMLStyleElement;
    protected _config: IStyleSheetConfig;
    private _styleElement?;
    private _rules;
    private _preservedRules;
    private _counter;
    private _keyToClassName;
    private _onInsertRuleCallbacks;
    private _onResetCallbacks;
    private _classNameToArgs;
    /**
     * Gets the singleton instance.
     */
    static getInstance(shadowConfig?: ShadowConfig): Stylesheet;
    constructor(config?: IStyleSheetConfig, serializedStylesheet?: ISerializedStylesheet);
    /**
     * Serializes the Stylesheet instance into a format which allows rehydration on creation.
     * @returns string representation of `ISerializedStylesheet` interface.
     */
    serialize(): string;
    /**
     * Configures the stylesheet.
     */
    setConfig(config?: IStyleSheetConfig): void;
    /**
     * Configures a reset callback.
     *
     * @param callback - A callback which will be called when the Stylesheet is reset.
     * @returns function which when called un-registers provided callback.
     */
    onReset(callback: Function): Function;
    /**
     * Configures an insert rule callback.
     *
     * @param callback - A callback which will be called when a rule is inserted.
     * @returns function which when called un-registers provided callback.
     */
    onInsertRule(callback: Function | InsertRuleCallback): Function;
    /**
     * Generates a unique classname.
     *
     * @param displayName - Optional value to use as a prefix.
     */
    getClassName(displayName?: string): string;
    /**
     * Used internally to cache information about a class which was
     * registered with the stylesheet.
     */
    cacheClassName(className: string, key: string, args: IStyle[], rules: string[]): void;
    /**
     * Gets the appropriate classname given a key which was previously
     * registered using cacheClassName.
     */
    classNameFromKey(key: string): string | undefined;
    /**
     * Gets all classnames cache with the stylesheet.
     */
    getClassNameCache(): {
        [key: string]: string;
    };
    /**
     * Gets the arguments associated with a given classname which was
     * previously registered using cacheClassName.
     */
    argsFromClassName(className: string): IStyle[] | undefined;
    /**
     * Gets the rules associated with a given classname which was
     * previously registered using cacheClassName.
     */
    insertedRulesFromClassName(className: string): string[] | undefined;
    /**
     * Inserts a css rule into the stylesheet.
     * @param preserve - Preserves the rule beyond a reset boundary.
     */
    insertRule(rule: string, preserve?: boolean, stylesheetKey?: string): void;
    /**
     * Gets all rules registered with the stylesheet; only valid when
     * using InsertionMode.none.
     */
    getRules(includePreservedRules?: boolean): string;
    /**
     * Resets the internal state of the stylesheet. Only used in server
     * rendered scenarios where we're using InsertionMode.none.
     */
    reset(): void;
    resetKeys(): void;
    protected _createStyleElement(): HTMLStyleElement;
    protected _insertRuleIntoSheet(sheet: CSSStyleSheet | undefined | null, rule: string): boolean;
    protected _getCacheKey(key: string): string;
    private _getStyleElement;
    private _findPlaceholderStyleTag;
}
export {};
