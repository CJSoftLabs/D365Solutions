export type ObjectOnly<TArg> = TArg extends {} ? TArg : {};
