export declare function kebabRules(rulePairs: (string | number)[], index: number): void;
