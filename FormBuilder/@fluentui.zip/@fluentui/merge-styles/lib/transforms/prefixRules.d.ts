export declare function prefixRules(rulePairs: (string | number)[], index: number): void;
