export declare function provideUnits(rulePairs: (string | number)[], index: number): void;
