import { IFontFace } from './IRawStyleBase';
/**
 * Registers a font face.
 * @public
 */
export declare function fontFace(font: IFontFace): void;
