import type { ExtendedCSSStyleSheet } from './Stylesheet';
export declare const cloneCSSStyleSheet: (srcSheet: CSSStyleSheet, targetSheet: CSSStyleSheet) => CSSStyleSheet;
export declare const cloneExtendedCSSStyleSheet: (srcSheet: ExtendedCSSStyleSheet, targetSheet: ExtendedCSSStyleSheet) => ExtendedCSSStyleSheet;
