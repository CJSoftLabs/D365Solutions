import { IStyle, IStyleBaseArray } from './IStyle';
import { Stylesheet } from './Stylesheet';
/**
 * Separates the classes and style objects. Any classes that are pre-registered
 * args are auto expanded into objects.
 */
export declare function extractStyleParts(sheet: Stylesheet, ...args: (IStyle | IStyle[] | false | null | undefined)[]): {
    classes: string[];
    objects: IStyleBaseArray;
};
