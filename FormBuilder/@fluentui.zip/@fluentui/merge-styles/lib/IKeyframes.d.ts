import { IRawStyle } from './IRawStyle';
/**
 * Keyframe definition.
 */
export type IKeyframes = Record<string, IRawStyle>;
