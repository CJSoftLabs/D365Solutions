import { IStyle, IStyleBaseArray } from './IStyle';
import { IStyleOptions } from './IStyleOptions';
import { ShadowConfig } from './shadowConfig';
type Missing = false | null | undefined;
type StyleArg = IStyle | IStyleBaseArray | Missing;
type StyleArgWithShadow = StyleArg | ShadowConfig;
export declare function mergeStyles(...args: StyleArg[]): string;
export declare function mergeStyles(shadowConfig: ShadowConfig, ...args: StyleArg[]): string;
/**
 * Concatenation helper, which can merge class names together. Skips over falsey values.
 * Accepts a set of options that will be used when calculating styles.
 *
 * @public
 */
export declare function mergeCss(args: StyleArgWithShadow | StyleArgWithShadow[], options?: IStyleOptions): string;
export {};
