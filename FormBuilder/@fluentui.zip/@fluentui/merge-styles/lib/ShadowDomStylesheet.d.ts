import { Stylesheet } from './Stylesheet';
import type { ExtendedCSSStyleSheet, ISerializedStylesheet, IStyleSheetConfig } from './Stylesheet';
import type { ShadowConfig } from './shadowConfig';
export declare const SUPPORTS_CONSTRUCTABLE_STYLESHEETS: boolean;
export declare const SUPPORTS_MODIFYING_ADOPTED_STYLESHEETS: boolean;
export type AddSheetCallback = ({ key, sheet }: {
    key: string;
    sheet: ExtendedCSSStyleSheet;
}) => void;
export declare class ShadowDomStylesheet extends Stylesheet {
    private _onAddSheetCallbacks;
    private _adoptableSheets;
    private _sheetCounter;
    static getInstance(shadowConfig?: ShadowConfig): ShadowDomStylesheet;
    constructor(config?: IStyleSheetConfig, serializedStylesheet?: ISerializedStylesheet);
    getAdoptedSheets(): Map<string, ExtendedCSSStyleSheet>;
    onAddSheet(callback: AddSheetCallback): Function;
    insertRule(rule: string, preserve?: boolean): void;
    protected _getCacheKey(key: string): string;
    protected _createStyleElement(): HTMLStyleElement;
    private _makeCSSStyleSheet;
    private _addAdoptableStyleSheet;
    private _getAdoptableStyleSheet;
}
