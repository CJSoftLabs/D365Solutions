export interface ShadowConfig {
    stylesheetKey: string;
    inShadow: boolean;
    window?: Window;
    __isShadowConfig__: true;
}
export declare const GLOBAL_STYLESHEET_KEY = "__global__";
export declare const SHADOW_DOM_STYLESHEET_SETTING = "__shadow_dom_stylesheet__";
export declare const DEFAULT_SHADOW_CONFIG: ShadowConfig;
export declare const makeShadowConfig: (stylesheetKey: string, inShadow: boolean, window?: Window) => ShadowConfig;
export declare const isShadowConfig: (value: unknown) => value is ShadowConfig;
