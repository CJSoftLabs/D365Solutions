define(["require", "exports", "./shadowConfig"], function (require, exports, shadowConfig_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.extractStyleParts = void 0;
    /**
     * Separates the classes and style objects. Any classes that are pre-registered
     * args are auto expanded into objects.
     */
    function extractStyleParts(sheet) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var classes = [];
        var objects = [];
        var stylesheet = sheet;
        function _processArgs(argsList) {
            for (var _i = 0, argsList_1 = argsList; _i < argsList_1.length; _i++) {
                var arg = argsList_1[_i];
                if (arg && !(0, shadowConfig_1.isShadowConfig)(arg)) {
                    if (typeof arg === 'string') {
                        if (arg.indexOf(' ') >= 0) {
                            _processArgs(arg.split(' '));
                        }
                        else {
                            var translatedArgs = stylesheet.argsFromClassName(arg);
                            if (translatedArgs) {
                                _processArgs(translatedArgs);
                            }
                            else {
                                // Avoid adding the same class twice.
                                if (classes.indexOf(arg) === -1) {
                                    classes.push(arg);
                                }
                            }
                        }
                    }
                    else if (Array.isArray(arg)) {
                        _processArgs(arg);
                    }
                    else if (typeof arg === 'object') {
                        objects.push(arg);
                    }
                }
            }
        }
        _processArgs(args);
        return {
            classes: classes,
            objects: objects,
        };
    }
    exports.extractStyleParts = extractStyleParts;
});
//# sourceMappingURL=extractStyleParts.js.map