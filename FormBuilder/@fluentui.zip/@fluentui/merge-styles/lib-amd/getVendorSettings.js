define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.setVendorSettings = exports.getVendorSettings = void 0;
    var _vendorSettings;
    function getVendorSettings() {
        var _a;
        if (!_vendorSettings) {
            // eslint-disable-next-line no-restricted-globals
            var doc = typeof document !== 'undefined' ? document : undefined;
            var nav = typeof navigator !== 'undefined' ? navigator : undefined;
            var userAgent = (_a = nav === null || nav === void 0 ? void 0 : nav.userAgent) === null || _a === void 0 ? void 0 : _a.toLowerCase();
            if (!doc) {
                _vendorSettings = {
                    isWebkit: true,
                    isMoz: true,
                    isOpera: true,
                    isMs: true,
                };
            }
            else {
                _vendorSettings = {
                    isWebkit: !!(doc && 'WebkitAppearance' in doc.documentElement.style),
                    isMoz: !!(userAgent && userAgent.indexOf('firefox') > -1),
                    isOpera: !!(userAgent && userAgent.indexOf('opera') > -1),
                    isMs: !!(nav && (/rv:11.0/i.test(nav.userAgent) || /Edge\/\d./i.test(navigator.userAgent))),
                };
            }
        }
        return _vendorSettings;
    }
    exports.getVendorSettings = getVendorSettings;
    /**
     * Sets the vendor settings for prefixing and vendor specific operations.
     */
    function setVendorSettings(vendorSettings) {
        _vendorSettings = vendorSettings;
    }
    exports.setVendorSettings = setVendorSettings;
});
//# sourceMappingURL=getVendorSettings.js.map