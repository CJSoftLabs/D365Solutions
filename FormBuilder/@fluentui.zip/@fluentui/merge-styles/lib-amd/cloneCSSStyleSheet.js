define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.cloneExtendedCSSStyleSheet = exports.cloneCSSStyleSheet = void 0;
    var cloneCSSStyleSheet = function (srcSheet, targetSheet) {
        for (var i = 0; i < srcSheet.cssRules.length; i++) {
            targetSheet.insertRule(srcSheet.cssRules[i].cssText, i);
        }
        return targetSheet;
    };
    exports.cloneCSSStyleSheet = cloneCSSStyleSheet;
    var cloneExtendedCSSStyleSheet = function (srcSheet, targetSheet) {
        var clone = (0, exports.cloneCSSStyleSheet)(srcSheet, targetSheet);
        clone.bucketName = srcSheet.bucketName;
        for (var _i = 0, _a = Object.keys(srcSheet.metadata); _i < _a.length; _i++) {
            var key = _a[_i];
            clone.metadata[key] = srcSheet.metadata[key];
        }
        return clone;
    };
    exports.cloneExtendedCSSStyleSheet = cloneExtendedCSSStyleSheet;
});
//# sourceMappingURL=cloneCSSStyleSheet.js.map