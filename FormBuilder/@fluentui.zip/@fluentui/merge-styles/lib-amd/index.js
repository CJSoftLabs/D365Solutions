define(["require", "exports", "./mergeStyles", "./mergeStyleSets", "./concatStyleSets", "./concatStyleSetsWithProps", "./fontFace", "./keyframes", "./Stylesheet", "./ShadowDomStylesheet", "./StyleOptionsState", "./shadowConfig", "./cloneCSSStyleSheet", "./version"], function (require, exports, mergeStyles_1, mergeStyleSets_1, concatStyleSets_1, concatStyleSetsWithProps_1, fontFace_1, keyframes_1, Stylesheet_1, ShadowDomStylesheet_1, StyleOptionsState_1, shadowConfig_1, cloneCSSStyleSheet_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.cloneCSSStyleSheet = exports.makeShadowConfig = exports.GLOBAL_STYLESHEET_KEY = exports.DEFAULT_SHADOW_CONFIG = exports.setRTL = exports.SUPPORTS_MODIFYING_ADOPTED_STYLESHEETS = exports.SUPPORTS_CONSTRUCTABLE_STYLESHEETS = exports.ShadowDomStylesheet = exports.Stylesheet = exports.InjectionMode = exports.keyframes = exports.fontFace = exports.concatStyleSetsWithProps = exports.concatStyleSets = exports.mergeCssSets = exports.mergeStyleSets = exports.mergeCss = exports.mergeStyles = void 0;
    Object.defineProperty(exports, "mergeStyles", { enumerable: true, get: function () { return mergeStyles_1.mergeStyles; } });
    Object.defineProperty(exports, "mergeCss", { enumerable: true, get: function () { return mergeStyles_1.mergeCss; } });
    Object.defineProperty(exports, "mergeStyleSets", { enumerable: true, get: function () { return mergeStyleSets_1.mergeStyleSets; } });
    Object.defineProperty(exports, "mergeCssSets", { enumerable: true, get: function () { return mergeStyleSets_1.mergeCssSets; } });
    Object.defineProperty(exports, "concatStyleSets", { enumerable: true, get: function () { return concatStyleSets_1.concatStyleSets; } });
    Object.defineProperty(exports, "concatStyleSetsWithProps", { enumerable: true, get: function () { return concatStyleSetsWithProps_1.concatStyleSetsWithProps; } });
    Object.defineProperty(exports, "fontFace", { enumerable: true, get: function () { return fontFace_1.fontFace; } });
    Object.defineProperty(exports, "keyframes", { enumerable: true, get: function () { return keyframes_1.keyframes; } });
    Object.defineProperty(exports, "InjectionMode", { enumerable: true, get: function () { return Stylesheet_1.InjectionMode; } });
    Object.defineProperty(exports, "Stylesheet", { enumerable: true, get: function () { return Stylesheet_1.Stylesheet; } });
    Object.defineProperty(exports, "ShadowDomStylesheet", { enumerable: true, get: function () { return ShadowDomStylesheet_1.ShadowDomStylesheet; } });
    Object.defineProperty(exports, "SUPPORTS_CONSTRUCTABLE_STYLESHEETS", { enumerable: true, get: function () { return ShadowDomStylesheet_1.SUPPORTS_CONSTRUCTABLE_STYLESHEETS; } });
    Object.defineProperty(exports, "SUPPORTS_MODIFYING_ADOPTED_STYLESHEETS", { enumerable: true, get: function () { return ShadowDomStylesheet_1.SUPPORTS_MODIFYING_ADOPTED_STYLESHEETS; } });
    Object.defineProperty(exports, "setRTL", { enumerable: true, get: function () { return StyleOptionsState_1.setRTL; } });
    Object.defineProperty(exports, "DEFAULT_SHADOW_CONFIG", { enumerable: true, get: function () { return shadowConfig_1.DEFAULT_SHADOW_CONFIG; } });
    Object.defineProperty(exports, "GLOBAL_STYLESHEET_KEY", { enumerable: true, get: function () { return shadowConfig_1.GLOBAL_STYLESHEET_KEY; } });
    Object.defineProperty(exports, "makeShadowConfig", { enumerable: true, get: function () { return shadowConfig_1.makeShadowConfig; } });
    Object.defineProperty(exports, "cloneCSSStyleSheet", { enumerable: true, get: function () { return cloneCSSStyleSheet_1.cloneCSSStyleSheet; } });
});
//# sourceMappingURL=index.js.map