define(["require", "exports", "./StyleOptionsState", "./Stylesheet", "./styleToClassName"], function (require, exports, StyleOptionsState_1, Stylesheet_1, styleToClassName_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fontFace = void 0;
    /**
     * Registers a font face.
     * @public
     */
    function fontFace(font) {
        var stylesheet = Stylesheet_1.Stylesheet.getInstance();
        var rule = (0, styleToClassName_1.serializeRuleEntries)((0, StyleOptionsState_1.getStyleOptions)(), font);
        var className = stylesheet.classNameFromKey(rule);
        if (className) {
            return;
        }
        var name = stylesheet.getClassName();
        stylesheet.insertRule("@font-face{".concat(rule, "}"), true);
        stylesheet.cacheClassName(name, rule, [], ['font-face', rule]);
    }
    exports.fontFace = fontFace;
});
//# sourceMappingURL=fontFace.js.map