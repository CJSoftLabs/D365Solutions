import * as p from '@fluentui/keyboard-key';

console.log(p);

export default {
  name: 'keyboard-key package',
};
