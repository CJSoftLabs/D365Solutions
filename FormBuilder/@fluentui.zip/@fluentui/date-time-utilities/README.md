# @fluentui/date-time-utilities

**Date and time utilities for [Fluent UI](https://developer.microsoft.com/en-us/fluentui)**

This package includes a number of date and time utility functions used by Fluent UI React DatePicker and Calendar components.

See [GitHub](https://github.com/microsoft/fluentui) for more details on the Fluent UI React project and packages within.
