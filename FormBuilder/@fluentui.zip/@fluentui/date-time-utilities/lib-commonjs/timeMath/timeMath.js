"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDateFromTimeSelection = exports.ceilMinuteToIncrement = exports.addMinutes = void 0;
var timeConstants_1 = require("../dateValues/timeConstants");
/**
 * Returns a date offset from the given date by the specified number of minutes.
 * @param date - The origin date
 * @param minutes - The number of minutes to offset. 'minutes' can be negative.
 * @returns A new Date object offset from the origin date by the given number of minutes
 */
var addMinutes = function (date, minutes) {
    var result = new Date(date.getTime());
    result.setTime(result.getTime() + minutes * timeConstants_1.TimeConstants.MinutesInOneHour * timeConstants_1.TimeConstants.MillisecondsIn1Sec);
    return result;
};
exports.addMinutes = addMinutes;
/**
 * Rounds the date's minute up to the next available increment. For example, if `date` has time 1:21
 * and `increments` is 5, the resulting time will be 1:25.
 * @param date - Date to ceil minutes
 * @param increments - Time increments
 * @returns Date with ceiled minute
 */
var ceilMinuteToIncrement = function (date, increments) {
    var result = new Date(date.getTime());
    var minute = result.getMinutes();
    if (timeConstants_1.TimeConstants.MinutesInOneHour % increments) {
        result.setMinutes(0);
    }
    else {
        var times = timeConstants_1.TimeConstants.MinutesInOneHour / increments;
        for (var i = 1; i <= times; i++) {
            if (minute > increments * (i - 1) && minute <= increments * i) {
                minute = increments * i;
                break;
            }
        }
        result.setMinutes(minute);
    }
    return result;
};
exports.ceilMinuteToIncrement = ceilMinuteToIncrement;
/**
 * Returns a date object from the selected time.
 * @param useHour12 - If the time picker uses 12 or 24 hour formatting
 * @param dateStartAnchor - The baseline date to calculate the offset of the selected time
 * @param selectedTime - A string representing the user selected time
 * @returns A new date object offset from the baseDate using the selected time.
 */
var getDateFromTimeSelection = function (useHour12, dateStartAnchor, selectedTime) {
    var _a = timeConstants_1.TimeConstants.TimeFormatRegex.exec(selectedTime) || [], selectedHours = _a[1], selectedMinutes = _a[2], selectedSeconds = _a[3], selectedAp = _a[4];
    var hours = +selectedHours;
    var minutes = +selectedMinutes;
    var seconds = selectedSeconds ? +selectedSeconds : 0;
    if (useHour12 && selectedAp) {
        if (selectedAp.toLowerCase() === 'pm' && hours !== timeConstants_1.TimeConstants.OffsetTo24HourFormat) {
            hours += timeConstants_1.TimeConstants.OffsetTo24HourFormat;
        }
        else if (selectedAp.toLowerCase() === 'am' && hours === timeConstants_1.TimeConstants.OffsetTo24HourFormat) {
            hours -= timeConstants_1.TimeConstants.OffsetTo24HourFormat;
        }
    }
    var hoursOffset;
    if (dateStartAnchor.getHours() > hours ||
        (dateStartAnchor.getHours() === hours && dateStartAnchor.getMinutes() > minutes)) {
        hoursOffset = timeConstants_1.TimeConstants.HoursInOneDay - dateStartAnchor.getHours() + hours;
    }
    else {
        hoursOffset = Math.abs(dateStartAnchor.getHours() - hours);
    }
    var offset = timeConstants_1.TimeConstants.MillisecondsIn1Sec * timeConstants_1.TimeConstants.MinutesInOneHour * hoursOffset * timeConstants_1.TimeConstants.SecondsInOneMinute +
        seconds * timeConstants_1.TimeConstants.MillisecondsIn1Sec;
    var date = new Date(dateStartAnchor.getTime() + offset);
    date.setMinutes(minutes);
    date.setSeconds(seconds);
    return date;
};
exports.getDateFromTimeSelection = getDateFromTimeSelection;
//# sourceMappingURL=timeMath.js.map