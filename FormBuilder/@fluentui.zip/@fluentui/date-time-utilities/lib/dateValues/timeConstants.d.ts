export declare const TimeConstants: {
    MillisecondsInOneDay: number;
    MillisecondsIn1Sec: number;
    MillisecondsIn1Min: number;
    MillisecondsIn30Mins: number;
    MillisecondsIn1Hour: number;
    MinutesInOneDay: number;
    MinutesInOneHour: number;
    DaysInOneWeek: number;
    MonthInOneYear: number;
    HoursInOneDay: number;
    SecondsInOneMinute: number;
    OffsetTo24HourFormat: number;
    /**
     * Matches a time string. Groups:
     * 1. hours (with or without leading 0)
     * 2. minutes
     * 3. seconds (optional)
     * 4. meridiem (am/pm, case-insensitive, optional)
     */
    TimeFormatRegex: RegExp;
};
