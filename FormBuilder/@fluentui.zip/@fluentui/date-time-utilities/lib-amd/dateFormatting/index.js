define(["require", "exports", "tslib", "./dateFormatting.types", "./dateFormatting.defaults"], function (require, exports, tslib_1, dateFormatting_types_1, dateFormatting_defaults_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    tslib_1.__exportStar(dateFormatting_types_1, exports);
    tslib_1.__exportStar(dateFormatting_defaults_1, exports);
});
//# sourceMappingURL=index.js.map