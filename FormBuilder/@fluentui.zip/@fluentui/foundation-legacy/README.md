# @fluentui/foundation-legacy

This library is deprecated. New [Fluent UI React](https://developer.microsoft.com/en-us/fluentui) components are no longer built on top of the patterns and utilities from this package.
