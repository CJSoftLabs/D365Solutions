/** Jest test setup file. */

const { setIconOptions } = require('@fluentui/style-utilities');

// Suppress icon warnings.
setIconOptions({
  disableWarnings: true,
});
