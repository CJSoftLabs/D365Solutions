define(["require", "exports", "@fluentui/set-version"], function (require, exports, set_version_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    (0, set_version_1.setVersion)('@fluentui/foundation-legacy', '8.4.30');
});
//# sourceMappingURL=version.js.map