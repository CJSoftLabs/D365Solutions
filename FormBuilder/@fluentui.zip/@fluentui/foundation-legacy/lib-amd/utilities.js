define(["require", "exports", "tslib"], function (require, exports, tslib_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.assign = void 0;
    exports.assign = tslib_1.__assign;
});
//# sourceMappingURL=utilities.js.map