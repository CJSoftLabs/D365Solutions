import { __assign } from 'tslib';
export declare const assign: typeof __assign;
