# Change Log - @fluentui/foundation-legacy

This log was last generated on Tue, 26 Aug 2025 07:19:44 GMT and should not be manually modified.

<!-- Start content -->

## [8.4.30](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.30)

Tue, 26 Aug 2025 07:19:44 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.29..@fluentui/foundation-legacy_v8.4.30)

### Patches

- Bump @fluentui/style-utilities to v8.12.4 ([commit](https://github.com/microsoft/fluentui/commit/54d698502c976954b7246ada9cc866e7c6a881a2) by beachball)

## [8.4.29](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.29)

Thu, 03 Jul 2025 07:21:37 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.28..@fluentui/foundation-legacy_v8.4.29)

### Patches

- chore: mitigate react 18 types breaking changes in non breaking way ([PR #34643](https://github.com/microsoft/fluentui/pull/34643) by martinhochel@microsoft.com)

## [8.4.28](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.28)

Fri, 16 May 2025 07:22:04 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.27..@fluentui/foundation-legacy_v8.4.28)

### Patches

- Bump @fluentui/style-utilities to v8.12.2 ([PR #34453](https://github.com/microsoft/fluentui/pull/34453) by beachball)
- Bump @fluentui/utilities to v8.15.22 ([PR #34453](https://github.com/microsoft/fluentui/pull/34453) by beachball)

## [8.4.27](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.27)

Thu, 08 May 2025 07:22:42 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.26..@fluentui/foundation-legacy_v8.4.27)

### Patches

- Bump @fluentui/style-utilities to v8.12.1 ([PR #34340](https://github.com/microsoft/fluentui/pull/34340) by beachball)
- Bump @fluentui/utilities to v8.15.21 ([PR #34340](https://github.com/microsoft/fluentui/pull/34340) by beachball)

## [8.4.26](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.26)

Tue, 15 Apr 2025 07:22:07 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.25..@fluentui/foundation-legacy_v8.4.26)

### Patches

- Bump @fluentui/style-utilities to v8.12.0 ([commit](https://github.com/microsoft/fluentui/commit/1e27b5f3579acf0392460ae6188e8c912fcd9e30) by beachball)

## [8.4.25](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.25)

Fri, 14 Mar 2025 07:23:16 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.24..@fluentui/foundation-legacy_v8.4.25)

### Patches

- Bump @fluentui/style-utilities to v8.11.8 ([PR #33981](https://github.com/microsoft/fluentui/pull/33981) by beachball)

## [8.4.24](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.24)

Fri, 21 Feb 2025 07:22:41 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.23..@fluentui/foundation-legacy_v8.4.24)

### Patches

- Bump @fluentui/merge-styles to v8.6.14 ([PR #33879](https://github.com/microsoft/fluentui/pull/33879) by beachball)
- Bump @fluentui/set-version to v8.2.24 ([PR #33879](https://github.com/microsoft/fluentui/pull/33879) by beachball)
- Bump @fluentui/style-utilities to v8.11.7 ([PR #33879](https://github.com/microsoft/fluentui/pull/33879) by beachball)
- Bump @fluentui/utilities to v8.15.20 ([PR #33879](https://github.com/microsoft/fluentui/pull/33879) by beachball)

## [8.4.23](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.23)

Mon, 23 Dec 2024 07:22:58 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.22..@fluentui/foundation-legacy_v8.4.23)

### Patches

- Bump @fluentui/style-utilities to v8.11.6 ([PR #33445](https://github.com/microsoft/fluentui/pull/33445) by beachball)

## [8.4.22](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.22)

Fri, 13 Dec 2024 07:23:12 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.21..@fluentui/foundation-legacy_v8.4.22)

### Patches

- Bump @fluentui/style-utilities to v8.11.5 ([PR #33455](https://github.com/microsoft/fluentui/pull/33455) by beachball)

## [8.4.21](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.21)

Fri, 01 Nov 2024 07:23:21 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.20..@fluentui/foundation-legacy_v8.4.21)

### Patches

- Bump @fluentui/style-utilities to v8.11.4 ([PR #33167](https://github.com/microsoft/fluentui/pull/33167) by beachball)

## [8.4.20](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.20)

Fri, 11 Oct 2024 16:51:54 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.19..@fluentui/foundation-legacy_v8.4.20)

### Patches

- Bump @fluentui/style-utilities to v8.11.3 ([PR #33024](https://github.com/microsoft/fluentui/pull/33024) by beachball)
- Bump @fluentui/utilities to v8.15.19 ([PR #33024](https://github.com/microsoft/fluentui/pull/33024) by beachball)

## [8.4.19](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.19)

Tue, 08 Oct 2024 07:23:46 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.18..@fluentui/foundation-legacy_v8.4.19)

### Patches

- Bump @fluentui/style-utilities to v8.11.2 ([PR #32971](https://github.com/microsoft/fluentui/pull/32971) by beachball)
- Bump @fluentui/utilities to v8.15.18 ([PR #32971](https://github.com/microsoft/fluentui/pull/32971) by beachball)

## [8.4.18](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.18)

Wed, 02 Oct 2024 07:23:57 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.17..@fluentui/foundation-legacy_v8.4.18)

### Patches

- Bump @fluentui/style-utilities to v8.11.1 ([PR #32920](https://github.com/microsoft/fluentui/pull/32920) by beachball)
- Bump @fluentui/utilities to v8.15.17 ([PR #32920](https://github.com/microsoft/fluentui/pull/32920) by beachball)

## [8.4.17](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.17)

Mon, 30 Sep 2024 07:23:12 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.16..@fluentui/foundation-legacy_v8.4.17)

### Patches

- Bump @fluentui/style-utilities to v8.11.0 ([PR #32437](https://github.com/microsoft/fluentui/pull/32437) by beachball)
- Bump @fluentui/utilities to v8.15.16 ([PR #32437](https://github.com/microsoft/fluentui/pull/32437) by beachball)

## [8.4.16](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.16)

Thu, 15 Aug 2024 07:23:36 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.15..@fluentui/foundation-legacy_v8.4.16)

### Patches

- Bump @fluentui/style-utilities to v8.10.21 ([PR #31484](https://github.com/microsoft/fluentui/pull/31484) by beachball)

## [8.4.15](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.15)

Thu, 08 Aug 2024 07:24:14 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.14..@fluentui/foundation-legacy_v8.4.15)

### Patches

- fix: ship bundled and umd code to registry ([PR #32212](https://github.com/microsoft/fluentui/pull/32212) by martinhochel@microsoft.com)
- Bump @fluentui/merge-styles to v8.6.13 ([commit](https://github.com/microsoft/fluentui/commit/0c2c905f8f567f47b7229104b542cfc1f936671a) by beachball)
- Bump @fluentui/style-utilities to v8.10.20 ([commit](https://github.com/microsoft/fluentui/commit/0c2c905f8f567f47b7229104b542cfc1f936671a) by beachball)
- Bump @fluentui/utilities to v8.15.15 ([commit](https://github.com/microsoft/fluentui/commit/0c2c905f8f567f47b7229104b542cfc1f936671a) by beachball)

## [8.4.14](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.14)

Thu, 01 Aug 2024 07:24:48 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.13..@fluentui/foundation-legacy_v8.4.14)

### Patches

- Bump @fluentui/style-utilities to v8.10.19 ([PR #32173](https://github.com/microsoft/fluentui/pull/32173) by beachball)
- Bump @fluentui/utilities to v8.15.14 ([PR #32173](https://github.com/microsoft/fluentui/pull/32173) by beachball)

## [8.4.13](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.13)

Tue, 09 Jul 2024 07:36:40 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.12..@fluentui/foundation-legacy_v8.4.13)

### Patches

- fix: revert incorectly set npm versions in all packages ([PR #31937](https://github.com/microsoft/fluentui/pull/31937) by martinhochel@microsoft.com)
- Bump @fluentui/style-utilities to v8.10.18 ([commit](https://github.com/microsoft/fluentui/commit/71daccf5b87388209fe648aeb64adf0b4cbdd9e6) by beachball)
- Bump @fluentui/utilities to v8.15.13 ([commit](https://github.com/microsoft/fluentui/commit/71daccf5b87388209fe648aeb64adf0b4cbdd9e6) by beachball)

## [8.4.12](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.12)

Tue, 25 Jun 2024 07:32:52 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.11..@fluentui/foundation-legacy_v8.4.12)

### Patches

- Bump @fluentui/merge-styles to v8.6.12 ([commit](https://github.com/microsoft/fluentui/commit/182a7b22c763910938a717db5f64456ede1bc504) by beachball)
- Bump @fluentui/style-utilities to v8.10.17 ([commit](https://github.com/microsoft/fluentui/commit/182a7b22c763910938a717db5f64456ede1bc504) by beachball)
- Bump @fluentui/utilities to v8.15.12 ([commit](https://github.com/microsoft/fluentui/commit/182a7b22c763910938a717db5f64456ede1bc504) by beachball)

## [8.4.11](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.11)

Mon, 24 Jun 2024 07:33:22 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.10..@fluentui/foundation-legacy_v8.4.11)

### Patches

- Bump @fluentui/merge-styles to v8.6.11 ([commit](https://github.com/microsoft/fluentui/commit/444d2ef497b5be5b4252f4af86ded3d2db7a0850) by beachball)
- Bump @fluentui/set-version to v8.2.23 ([commit](https://github.com/microsoft/fluentui/commit/444d2ef497b5be5b4252f4af86ded3d2db7a0850) by beachball)
- Bump @fluentui/style-utilities to v8.10.16 ([commit](https://github.com/microsoft/fluentui/commit/444d2ef497b5be5b4252f4af86ded3d2db7a0850) by beachball)
- Bump @fluentui/utilities to v8.15.11 ([commit](https://github.com/microsoft/fluentui/commit/444d2ef497b5be5b4252f4af86ded3d2db7a0850) by beachball)

## [8.4.10](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.10)

Fri, 14 Jun 2024 15:25:28 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.9..@fluentui/foundation-legacy_v8.4.10)

### Patches

- Bump @fluentui/merge-styles to v8.6.10 ([PR #31716](https://github.com/microsoft/fluentui/pull/31716) by beachball)
- Bump @fluentui/style-utilities to v8.10.15 ([PR #31716](https://github.com/microsoft/fluentui/pull/31716) by beachball)
- Bump @fluentui/utilities to v8.15.10 ([PR #31716](https://github.com/microsoft/fluentui/pull/31716) by beachball)

## [8.4.9](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.9)

Thu, 06 Jun 2024 07:26:46 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.8..@fluentui/foundation-legacy_v8.4.9)

### Patches

- Bump @fluentui/merge-styles to v8.6.9 ([commit](https://github.com/microsoft/fluentui/commit/e5e806f46bd00bc7baffbfe7514a617600ba2d47) by beachball)
- Bump @fluentui/set-version to v8.2.22 ([commit](https://github.com/microsoft/fluentui/commit/e5e806f46bd00bc7baffbfe7514a617600ba2d47) by beachball)
- Bump @fluentui/style-utilities to v8.10.14 ([commit](https://github.com/microsoft/fluentui/commit/e5e806f46bd00bc7baffbfe7514a617600ba2d47) by beachball)
- Bump @fluentui/utilities to v8.15.9 ([commit](https://github.com/microsoft/fluentui/commit/e5e806f46bd00bc7baffbfe7514a617600ba2d47) by beachball)

## [8.4.8](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.8)

Tue, 28 May 2024 07:28:20 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.7..@fluentui/foundation-legacy_v8.4.8)

### Patches

- Bump @fluentui/merge-styles to v8.6.8 ([PR #31324](https://github.com/microsoft/fluentui/pull/31324) by beachball)
- Bump @fluentui/set-version to v8.2.21 ([PR #31324](https://github.com/microsoft/fluentui/pull/31324) by beachball)
- Bump @fluentui/style-utilities to v8.10.13 ([PR #31324](https://github.com/microsoft/fluentui/pull/31324) by beachball)
- Bump @fluentui/utilities to v8.15.8 ([PR #31324](https://github.com/microsoft/fluentui/pull/31324) by beachball)

## [8.4.7](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.7)

Fri, 24 May 2024 07:28:17 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.6..@fluentui/foundation-legacy_v8.4.7)

### Patches

- Bump @fluentui/merge-styles to v8.6.7 ([commit](https://github.com/microsoft/fluentui/commit/e5b614623b9aa1ae3f1f86f3e753b934943a4601) by beachball)
- Bump @fluentui/set-version to v8.2.20 ([commit](https://github.com/microsoft/fluentui/commit/e5b614623b9aa1ae3f1f86f3e753b934943a4601) by beachball)
- Bump @fluentui/style-utilities to v8.10.12 ([commit](https://github.com/microsoft/fluentui/commit/e5b614623b9aa1ae3f1f86f3e753b934943a4601) by beachball)
- Bump @fluentui/utilities to v8.15.7 ([commit](https://github.com/microsoft/fluentui/commit/e5b614623b9aa1ae3f1f86f3e753b934943a4601) by beachball)

## [8.4.6](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.6)

Thu, 23 May 2024 07:28:51 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.5..@fluentui/foundation-legacy_v8.4.6)

### Patches

- Bump @fluentui/merge-styles to v8.6.6 ([commit](https://github.com/microsoft/fluentui/commit/10e6758b203de79c53ce31ba264e137f83f50ff4) by beachball)
- Bump @fluentui/set-version to v8.2.19 ([commit](https://github.com/microsoft/fluentui/commit/10e6758b203de79c53ce31ba264e137f83f50ff4) by beachball)
- Bump @fluentui/style-utilities to v8.10.11 ([commit](https://github.com/microsoft/fluentui/commit/10e6758b203de79c53ce31ba264e137f83f50ff4) by beachball)
- Bump @fluentui/utilities to v8.15.6 ([commit](https://github.com/microsoft/fluentui/commit/10e6758b203de79c53ce31ba264e137f83f50ff4) by beachball)

## [8.4.5](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.5)

Mon, 20 May 2024 07:29:20 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.4..@fluentui/foundation-legacy_v8.4.5)

### Patches

- Bump @fluentui/merge-styles to v8.6.5 ([commit](https://github.com/microsoft/fluentui/commit/eadc00f974b3199e6c34d2e9d16015add154ec3b) by beachball)
- Bump @fluentui/set-version to v8.2.18 ([commit](https://github.com/microsoft/fluentui/commit/eadc00f974b3199e6c34d2e9d16015add154ec3b) by beachball)
- Bump @fluentui/style-utilities to v8.10.10 ([commit](https://github.com/microsoft/fluentui/commit/eadc00f974b3199e6c34d2e9d16015add154ec3b) by beachball)
- Bump @fluentui/utilities to v8.15.5 ([commit](https://github.com/microsoft/fluentui/commit/eadc00f974b3199e6c34d2e9d16015add154ec3b) by beachball)

## [8.4.4](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.4)

Wed, 24 Apr 2024 07:27:48 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.3..@fluentui/foundation-legacy_v8.4.4)

### Patches

- Bump @fluentui/merge-styles to v8.6.4 ([PR #31130](https://github.com/microsoft/fluentui/pull/31130) by beachball)
- Bump @fluentui/set-version to v8.2.17 ([PR #31130](https://github.com/microsoft/fluentui/pull/31130) by beachball)
- Bump @fluentui/style-utilities to v8.10.9 ([PR #31130](https://github.com/microsoft/fluentui/pull/31130) by beachball)
- Bump @fluentui/utilities to v8.15.4 ([PR #31130](https://github.com/microsoft/fluentui/pull/31130) by beachball)

## [8.4.3](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.3)

Mon, 22 Apr 2024 07:28:27 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.2..@fluentui/foundation-legacy_v8.4.3)

### Patches

- Bump @fluentui/merge-styles to v8.6.3 ([PR #31126](https://github.com/microsoft/fluentui/pull/31126) by beachball)
- Bump @fluentui/style-utilities to v8.10.8 ([PR #31126](https://github.com/microsoft/fluentui/pull/31126) by beachball)
- Bump @fluentui/utilities to v8.15.3 ([PR #31126](https://github.com/microsoft/fluentui/pull/31126) by beachball)

## [8.4.2](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.2)

Fri, 12 Apr 2024 07:29:11 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.1..@fluentui/foundation-legacy_v8.4.2)

### Patches

- Bump @fluentui/merge-styles to v8.6.2 ([PR #31022](https://github.com/microsoft/fluentui/pull/31022) by beachball)
- Bump @fluentui/set-version to v8.2.16 ([PR #31022](https://github.com/microsoft/fluentui/pull/31022) by beachball)
- Bump @fluentui/style-utilities to v8.10.7 ([PR #31022](https://github.com/microsoft/fluentui/pull/31022) by beachball)
- Bump @fluentui/utilities to v8.15.2 ([PR #31022](https://github.com/microsoft/fluentui/pull/31022) by beachball)

## [8.4.1](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.1)

Wed, 03 Apr 2024 07:29:31 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.4.0..@fluentui/foundation-legacy_v8.4.1)

### Patches

- Bump @fluentui/merge-styles to v8.6.1 ([PR #30943](https://github.com/microsoft/fluentui/pull/30943) by beachball)
- Bump @fluentui/set-version to v8.2.15 ([PR #30943](https://github.com/microsoft/fluentui/pull/30943) by beachball)
- Bump @fluentui/style-utilities to v8.10.6 ([PR #30943](https://github.com/microsoft/fluentui/pull/30943) by beachball)
- Bump @fluentui/utilities to v8.15.1 ([PR #30943](https://github.com/microsoft/fluentui/pull/30943) by beachball)

## [8.4.0](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.4.0)

Fri, 22 Mar 2024 07:28:52 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.3.0..@fluentui/foundation-legacy_v8.4.0)

### Minor changes

- fix: Build errors in TypeScript 5.3 ([PR #30808](https://github.com/microsoft/fluentui/pull/30808) by behowell@microsoft.com)
- Bump @fluentui/style-utilities to v8.10.5 ([PR #30817](https://github.com/microsoft/fluentui/pull/30817) by beachball)
- Bump @fluentui/utilities to v8.15.0 ([PR #30817](https://github.com/microsoft/fluentui/pull/30817) by beachball)

## [8.3.0](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.3.0)

Wed, 13 Mar 2024 07:30:27 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.52..@fluentui/foundation-legacy_v8.3.0)

### Minor changes

- fix: Update IStyleSet type to fix error when using TypeScript 5.3+ ([PR #30753](https://github.com/microsoft/fluentui/pull/30753) by behowell@microsoft.com)
- Bump @fluentui/merge-styles to v8.6.0 ([PR #30753](https://github.com/microsoft/fluentui/pull/30753) by beachball)
- Bump @fluentui/style-utilities to v8.10.4 ([PR #30753](https://github.com/microsoft/fluentui/pull/30753) by beachball)
- Bump @fluentui/utilities to v8.14.0 ([PR #30753](https://github.com/microsoft/fluentui/pull/30753) by beachball)

## [8.2.52](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.52)

Wed, 31 Jan 2024 07:27:57 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.51..@fluentui/foundation-legacy_v8.2.52)

### Patches

- Bump @fluentui/style-utilities to v8.10.3 ([commit](https://github.com/microsoft/fluentui/commit/eeb2656f81977a5821c36ca854fe2781d9dcfd1b) by beachball)

## [8.2.51](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.51)

Fri, 19 Jan 2024 07:29:32 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.50..@fluentui/foundation-legacy_v8.2.51)

### Patches

- Bump @fluentui/style-utilities to v8.10.2 ([PR #30225](https://github.com/microsoft/fluentui/pull/30225) by beachball)
- Bump @fluentui/utilities to v8.13.24 ([PR #30225](https://github.com/microsoft/fluentui/pull/30225) by beachball)

## [8.2.50](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.50)

Wed, 10 Jan 2024 07:28:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.49..@fluentui/foundation-legacy_v8.2.50)

### Patches

- Bump @fluentui/merge-styles to v8.5.15 ([PR #30063](https://github.com/microsoft/fluentui/pull/30063) by beachball)
- Bump @fluentui/set-version to v8.2.14 ([PR #30063](https://github.com/microsoft/fluentui/pull/30063) by beachball)
- Bump @fluentui/style-utilities to v8.10.1 ([PR #30063](https://github.com/microsoft/fluentui/pull/30063) by beachball)
- Bump @fluentui/utilities to v8.13.23 ([PR #30063](https://github.com/microsoft/fluentui/pull/30063) by beachball)

## [8.2.49](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.49)

Tue, 09 Jan 2024 07:33:09 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.48..@fluentui/foundation-legacy_v8.2.49)

### Patches

- Bump @fluentui/style-utilities to v8.10.0 ([PR #30003](https://github.com/microsoft/fluentui/pull/30003) by beachball)

## [8.2.48](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.48)

Thu, 14 Dec 2023 07:30:10 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.47..@fluentui/foundation-legacy_v8.2.48)

### Patches

- Bump @fluentui/merge-styles to v8.5.14 ([PR #30061](https://github.com/microsoft/fluentui/pull/30061) by beachball)
- Bump @fluentui/set-version to v8.2.13 ([PR #30061](https://github.com/microsoft/fluentui/pull/30061) by beachball)
- Bump @fluentui/style-utilities to v8.9.21 ([PR #30061](https://github.com/microsoft/fluentui/pull/30061) by beachball)
- Bump @fluentui/utilities to v8.13.22 ([PR #30061](https://github.com/microsoft/fluentui/pull/30061) by beachball)

## [8.2.47](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.47)

Thu, 09 Nov 2023 07:29:20 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.46..@fluentui/foundation-legacy_v8.2.47)

### Patches

- Bump @fluentui/style-utilities to v8.9.20 ([PR #29772](https://github.com/microsoft/fluentui/pull/29772) by beachball)
- Bump @fluentui/utilities to v8.13.21 ([PR #29772](https://github.com/microsoft/fluentui/pull/29772) by beachball)

## [8.2.46](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.46)

Sat, 28 Oct 2023 00:29:16 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.45..@fluentui/foundation-legacy_v8.2.46)

### Patches

- Bump @fluentui/merge-styles to v8.5.13 ([commit](https://github.com/microsoft/fluentui/commit/70d0762fd12eb211f7c1dbe31a23b2fbb73a67c4) by beachball)
- Bump @fluentui/set-version to v8.2.12 ([commit](https://github.com/microsoft/fluentui/commit/70d0762fd12eb211f7c1dbe31a23b2fbb73a67c4) by beachball)
- Bump @fluentui/style-utilities to v8.9.19 ([commit](https://github.com/microsoft/fluentui/commit/70d0762fd12eb211f7c1dbe31a23b2fbb73a67c4) by beachball)
- Bump @fluentui/utilities to v8.13.20 ([commit](https://github.com/microsoft/fluentui/commit/70d0762fd12eb211f7c1dbe31a23b2fbb73a67c4) by beachball)

## [8.2.45](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.45)

Fri, 29 Sep 2023 07:45:30 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.44..@fluentui/foundation-legacy_v8.2.45)

### Patches

- Bump @fluentui/style-utilities to v8.9.18 ([PR #29313](https://github.com/microsoft/fluentui/pull/29313) by beachball)
- Bump @fluentui/utilities to v8.13.19 ([PR #29313](https://github.com/microsoft/fluentui/pull/29313) by beachball)

## [8.2.44](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.44)

Fri, 18 Aug 2023 07:35:26 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.43..@fluentui/foundation-legacy_v8.2.44)

### Patches

- Bump @fluentui/style-utilities to v8.9.17 ([PR #28862](https://github.com/microsoft/fluentui/pull/28862) by beachball)

## [8.2.43](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.43)

Wed, 28 Jun 2023 07:37:33 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.42..@fluentui/foundation-legacy_v8.2.43)

### Patches

- Bump @fluentui/style-utilities to v8.9.16 ([PR #28335](https://github.com/microsoft/fluentui/pull/28335) by beachball)
- Bump @fluentui/utilities to v8.13.18 ([PR #28335](https://github.com/microsoft/fluentui/pull/28335) by beachball)

## [8.2.42](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.42)

Mon, 19 Jun 2023 07:36:39 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.41..@fluentui/foundation-legacy_v8.2.42)

### Patches

- Bump @fluentui/style-utilities to v8.9.15 ([PR #28234](https://github.com/microsoft/fluentui/pull/28234) by beachball)
- Bump @fluentui/utilities to v8.13.17 ([PR #28234](https://github.com/microsoft/fluentui/pull/28234) by beachball)

## [8.2.41](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.41)

Thu, 01 Jun 2023 07:38:37 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.40..@fluentui/foundation-legacy_v8.2.41)

### Patches

- Bump @fluentui/style-utilities to v8.9.14 ([PR #28080](https://github.com/microsoft/fluentui/pull/28080) by beachball)
- Bump @fluentui/utilities to v8.13.16 ([PR #28080](https://github.com/microsoft/fluentui/pull/28080) by beachball)

## [8.2.40](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.40)

Wed, 31 May 2023 07:38:40 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.39..@fluentui/foundation-legacy_v8.2.40)

### Patches

- Bump @fluentui/merge-styles to v8.5.12 ([commit](https://github.com/microsoft/fluentui/commit/dd8c30d9b97f68eb332366fc0e69775a88775319) by beachball)
- Bump @fluentui/set-version to v8.2.11 ([commit](https://github.com/microsoft/fluentui/commit/dd8c30d9b97f68eb332366fc0e69775a88775319) by beachball)
- Bump @fluentui/style-utilities to v8.9.13 ([commit](https://github.com/microsoft/fluentui/commit/dd8c30d9b97f68eb332366fc0e69775a88775319) by beachball)
- Bump @fluentui/utilities to v8.13.15 ([commit](https://github.com/microsoft/fluentui/commit/dd8c30d9b97f68eb332366fc0e69775a88775319) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.29 ([commit](https://github.com/microsoft/fluentui/commit/dd8c30d9b97f68eb332366fc0e69775a88775319) by beachball)

## [8.2.39](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.39)

Tue, 30 May 2023 07:36:09 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.38..@fluentui/foundation-legacy_v8.2.39)

### Patches

- Bump @fluentui/merge-styles to v8.5.11 ([PR #27685](https://github.com/microsoft/fluentui/pull/27685) by beachball)
- Bump @fluentui/set-version to v8.2.10 ([PR #27685](https://github.com/microsoft/fluentui/pull/27685) by beachball)
- Bump @fluentui/style-utilities to v8.9.12 ([PR #27685](https://github.com/microsoft/fluentui/pull/27685) by beachball)
- Bump @fluentui/utilities to v8.13.14 ([PR #27685](https://github.com/microsoft/fluentui/pull/27685) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.28 ([PR #27685](https://github.com/microsoft/fluentui/pull/27685) by beachball)

## [8.2.38](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.38)

Fri, 26 May 2023 07:37:02 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.37..@fluentui/foundation-legacy_v8.2.38)

### Patches

- Bump @fluentui/style-utilities to v8.9.11 ([PR #27929](https://github.com/microsoft/fluentui/pull/27929) by beachball)

## [8.2.37](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.37)

Fri, 05 May 2023 18:14:04 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.36..@fluentui/foundation-legacy_v8.2.37)

### Patches

- fix: explicitly ship dist/ folder. ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by tristan.watanabe@gmail.com)
- Bump @fluentui/merge-styles to v8.5.10 ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by beachball)
- Bump @fluentui/set-version to v8.2.9 ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by beachball)
- Bump @fluentui/style-utilities to v8.9.10 ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by beachball)
- Bump @fluentui/utilities to v8.13.13 ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.27 ([PR #27769](https://github.com/microsoft/fluentui/pull/27769) by beachball)

## [8.2.36](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.36)

Tue, 02 May 2023 22:20:25 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.35..@fluentui/foundation-legacy_v8.2.36)

### Patches

- Bump @fluentui/style-utilities to v8.9.9 ([PR #27745](https://github.com/microsoft/fluentui/pull/27745) by beachball)
- Bump @fluentui/utilities to v8.13.12 ([PR #27745](https://github.com/microsoft/fluentui/pull/27745) by beachball)

## [8.2.35](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.35)

Tue, 02 May 2023 00:58:15 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.34..@fluentui/foundation-legacy_v8.2.35)

### Patches

- fix: esm, cjs, and amd folders should all be published correctly. ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by tristan.watanabe@gmail.com)
- Bump @fluentui/merge-styles to v8.5.9 ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by beachball)
- Bump @fluentui/set-version to v8.2.8 ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by beachball)
- Bump @fluentui/style-utilities to v8.9.8 ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by beachball)
- Bump @fluentui/utilities to v8.13.11 ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.26 ([PR #27736](https://github.com/microsoft/fluentui/pull/27736) by beachball)

## [8.2.34](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.34)

Mon, 01 May 2023 07:39:54 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.33..@fluentui/foundation-legacy_v8.2.34)

### Patches

- Bump @fluentui/merge-styles to v8.5.8 ([PR #27724](https://github.com/microsoft/fluentui/pull/27724) by beachball)
- Bump @fluentui/set-version to v8.2.7 ([PR #27724](https://github.com/microsoft/fluentui/pull/27724) by beachball)
- Bump @fluentui/style-utilities to v8.9.7 ([PR #27724](https://github.com/microsoft/fluentui/pull/27724) by beachball)
- Bump @fluentui/utilities to v8.13.10 ([PR #27724](https://github.com/microsoft/fluentui/pull/27724) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.25 ([PR #27724](https://github.com/microsoft/fluentui/pull/27724) by beachball)

## [8.2.33](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.33)

Fri, 17 Mar 2023 08:15:56 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.32..@fluentui/foundation-legacy_v8.2.33)

### Patches

- Bump @fluentui/merge-styles to v8.5.7 ([PR #27210](https://github.com/microsoft/fluentui/pull/27210) by beachball)
- Bump @fluentui/set-version to v8.2.6 ([PR #27210](https://github.com/microsoft/fluentui/pull/27210) by beachball)
- Bump @fluentui/style-utilities to v8.9.6 ([PR #27210](https://github.com/microsoft/fluentui/pull/27210) by beachball)
- Bump @fluentui/utilities to v8.13.9 ([PR #27210](https://github.com/microsoft/fluentui/pull/27210) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.24 ([PR #27210](https://github.com/microsoft/fluentui/pull/27210) by beachball)

## [8.2.32](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.32)

Thu, 09 Mar 2023 07:39:12 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.31..@fluentui/foundation-legacy_v8.2.32)

### Patches

- Bump @fluentui/style-utilities to v8.9.5 ([PR #27119](https://github.com/microsoft/fluentui/pull/27119) by beachball)

## [8.2.31](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.31)

Mon, 06 Mar 2023 07:43:04 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.30..@fluentui/foundation-legacy_v8.2.31)

### Patches

- Bump @fluentui/style-utilities to v8.9.4 ([PR #26869](https://github.com/microsoft/fluentui/pull/26869) by beachball)

## [8.2.30](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.30)

Wed, 01 Mar 2023 07:45:41 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.29..@fluentui/foundation-legacy_v8.2.30)

### Patches

- Bump @fluentui/style-utilities to v8.9.3 ([PR #26980](https://github.com/microsoft/fluentui/pull/26980) by beachball)
- Bump @fluentui/utilities to v8.13.8 ([PR #26980](https://github.com/microsoft/fluentui/pull/26980) by beachball)

## [8.2.29](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.29)

Sat, 18 Feb 2023 01:37:02 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.28..@fluentui/foundation-legacy_v8.2.29)

### Patches

- Bump @fluentui/style-utilities to v8.9.2 ([PR #26903](https://github.com/microsoft/fluentui/pull/26903) by beachball)
- Bump @fluentui/utilities to v8.13.7 ([PR #26903](https://github.com/microsoft/fluentui/pull/26903) by beachball)

## [8.2.28](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.28)

Fri, 03 Feb 2023 07:50:06 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.27..@fluentui/foundation-legacy_v8.2.28)

### Patches

- Bump @fluentui/merge-styles to v8.5.6 ([PR #26569](https://github.com/microsoft/fluentui/pull/26569) by beachball)
- Bump @fluentui/set-version to v8.2.5 ([PR #26569](https://github.com/microsoft/fluentui/pull/26569) by beachball)
- Bump @fluentui/style-utilities to v8.9.1 ([PR #26569](https://github.com/microsoft/fluentui/pull/26569) by beachball)
- Bump @fluentui/utilities to v8.13.6 ([PR #26569](https://github.com/microsoft/fluentui/pull/26569) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.23 ([PR #26569](https://github.com/microsoft/fluentui/pull/26569) by beachball)

## [8.2.27](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.27)

Fri, 27 Jan 2023 07:37:51 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.26..@fluentui/foundation-legacy_v8.2.27)

### Patches

- Bump @fluentui/style-utilities to v8.9.0 ([PR #26520](https://github.com/microsoft/fluentui/pull/26520) by beachball)

## [8.2.26](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.26)

Tue, 10 Jan 2023 07:50:15 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.25..@fluentui/foundation-legacy_v8.2.26)

### Patches

- Bump @fluentui/merge-styles to v8.5.5 ([PR #26260](https://github.com/microsoft/fluentui/pull/26260) by beachball)
- Bump @fluentui/set-version to v8.2.4 ([PR #26260](https://github.com/microsoft/fluentui/pull/26260) by beachball)
- Bump @fluentui/style-utilities to v8.8.5 ([PR #26260](https://github.com/microsoft/fluentui/pull/26260) by beachball)
- Bump @fluentui/utilities to v8.13.5 ([PR #26260](https://github.com/microsoft/fluentui/pull/26260) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.22 ([PR #26260](https://github.com/microsoft/fluentui/pull/26260) by beachball)

## [8.2.25](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.25)

Tue, 20 Dec 2022 07:53:34 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.24..@fluentui/foundation-legacy_v8.2.25)

### Patches

- Bump @fluentui/style-utilities to v8.8.4 ([PR #26005](https://github.com/microsoft/fluentui/pull/26005) by beachball)

## [8.2.24](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.24)

Tue, 15 Nov 2022 07:44:59 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.23..@fluentui/foundation-legacy_v8.2.24)

### Patches

- Bump @fluentui/style-utilities to v8.8.3 ([PR #25643](https://github.com/microsoft/fluentui/pull/25643) by beachball)
- Bump @fluentui/utilities to v8.13.4 ([PR #25643](https://github.com/microsoft/fluentui/pull/25643) by beachball)

## [8.2.23](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.23)

Wed, 09 Nov 2022 07:48:12 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.22..@fluentui/foundation-legacy_v8.2.23)

### Patches

- Bump @fluentui/merge-styles to v8.5.4 ([PR #25564](https://github.com/microsoft/fluentui/pull/25564) by beachball)
- Bump @fluentui/set-version to v8.2.3 ([PR #25564](https://github.com/microsoft/fluentui/pull/25564) by beachball)
- Bump @fluentui/style-utilities to v8.8.2 ([PR #25564](https://github.com/microsoft/fluentui/pull/25564) by beachball)
- Bump @fluentui/utilities to v8.13.3 ([PR #25564](https://github.com/microsoft/fluentui/pull/25564) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.21 ([PR #25564](https://github.com/microsoft/fluentui/pull/25564) by beachball)

## [8.2.22](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.22)

Thu, 20 Oct 2022 07:43:14 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.21..@fluentui/foundation-legacy_v8.2.22)

### Patches

- chore: Bump react peer dependency to react 18. ([PR #25278](https://github.com/microsoft/fluentui/pull/25278) by mgodbolt@microsoft.com)
- Bump @fluentui/style-utilities to v8.8.1 ([PR #25294](https://github.com/microsoft/fluentui/pull/25294) by beachball)
- Bump @fluentui/utilities to v8.13.2 ([PR #25294](https://github.com/microsoft/fluentui/pull/25294) by beachball)

## [8.2.21](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.21)

Mon, 10 Oct 2022 07:38:24 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.20..@fluentui/foundation-legacy_v8.2.21)

### Patches

- Bump @fluentui/style-utilities to v8.8.0 ([PR #25138](https://github.com/microsoft/fluentui/pull/25138) by beachball)

## [8.2.20](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.20)

Fri, 02 Sep 2022 07:48:53 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.19..@fluentui/foundation-legacy_v8.2.20)

### Patches

- Bump @fluentui/style-utilities to v8.7.12 ([PR #24394](https://github.com/microsoft/fluentui/pull/24394) by beachball)
- Bump @fluentui/utilities to v8.13.1 ([PR #24394](https://github.com/microsoft/fluentui/pull/24394) by beachball)

## [8.2.19](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.19)

Thu, 01 Sep 2022 07:48:11 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.18..@fluentui/foundation-legacy_v8.2.19)

### Patches

- Bump @fluentui/style-utilities to v8.7.11 ([PR #24599](https://github.com/microsoft/fluentui/pull/24599) by beachball)

## [8.2.18](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.18)

Mon, 29 Aug 2022 07:44:38 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.17..@fluentui/foundation-legacy_v8.2.18)

### Patches

- Bump @fluentui/style-utilities to v8.7.10 ([PR #24554](https://github.com/microsoft/fluentui/pull/24554) by beachball)
- Bump @fluentui/utilities to v8.13.0 ([PR #24554](https://github.com/microsoft/fluentui/pull/24554) by beachball)

## [8.2.17](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.17)

Wed, 24 Aug 2022 16:36:05 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.16..@fluentui/foundation-legacy_v8.2.17)

### Patches

- fix: fixes broken publish. ([PR #24500](https://github.com/microsoft/fluentui/pull/24500) by tristan.watanabe@gmail.com)
- Bump @fluentui/style-utilities to v8.7.9 ([PR #24485](https://github.com/microsoft/fluentui/pull/24485) by beachball)

## [8.2.16](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.16)

Tue, 23 Aug 2022 07:22:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.15..@fluentui/foundation-legacy_v8.2.16)

### Patches

- fix: Add React 17 support. ([PR #24356](https://github.com/microsoft/fluentui/pull/24356) by tristan.watanabe@gmail.com)
- Bump @fluentui/style-utilities to v8.7.8 ([PR #24332](https://github.com/microsoft/fluentui/pull/24332) by beachball)

## [8.2.15](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.15)

Thu, 18 Aug 2022 23:39:31 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.14..@fluentui/foundation-legacy_v8.2.15)

### Patches

- Bump @fluentui/style-utilities to v8.7.7 ([PR #24406](https://github.com/microsoft/fluentui/pull/24406) by beachball)
- Bump @fluentui/utilities to v8.12.0 ([PR #24406](https://github.com/microsoft/fluentui/pull/24406) by beachball)

## [8.2.14](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.14)

Mon, 15 Aug 2022 07:39:41 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.13..@fluentui/foundation-legacy_v8.2.14)

### Patches

- Bump @fluentui/style-utilities to v8.7.6 ([PR #24359](https://github.com/microsoft/fluentui/pull/24359) by beachball)
- Bump @fluentui/utilities to v8.11.0 ([PR #24359](https://github.com/microsoft/fluentui/pull/24359) by beachball)

## [8.2.13](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.13)

Mon, 08 Aug 2022 07:39:33 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.12..@fluentui/foundation-legacy_v8.2.13)

### Patches

- Bump @fluentui/merge-styles to v8.5.3 ([PR #24212](https://github.com/microsoft/fluentui/pull/24212) by beachball)
- Bump @fluentui/set-version to v8.2.2 ([PR #24212](https://github.com/microsoft/fluentui/pull/24212) by beachball)
- Bump @fluentui/style-utilities to v8.7.5 ([PR #24212](https://github.com/microsoft/fluentui/pull/24212) by beachball)
- Bump @fluentui/utilities to v8.10.2 ([PR #24212](https://github.com/microsoft/fluentui/pull/24212) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.20 ([PR #24212](https://github.com/microsoft/fluentui/pull/24212) by beachball)

## [8.2.12](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.12)

Tue, 02 Aug 2022 07:44:44 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.11..@fluentui/foundation-legacy_v8.2.12)

### Patches

- Bump @fluentui/style-utilities to v8.7.4 ([PR #24032](https://github.com/microsoft/fluentui/pull/24032) by beachball)
- Bump @fluentui/utilities to v8.10.1 ([PR #24032](https://github.com/microsoft/fluentui/pull/24032) by beachball)

## [8.2.11](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.11)

Tue, 26 Jul 2022 07:39:35 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.10..@fluentui/foundation-legacy_v8.2.11)

### Patches

- Bump @fluentui/style-utilities to v8.7.3 ([PR #24068](https://github.com/microsoft/fluentui/pull/24068) by beachball)
- Bump @fluentui/utilities to v8.10.0 ([PR #24068](https://github.com/microsoft/fluentui/pull/24068) by beachball)

## [8.2.10](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.10)

Tue, 12 Jul 2022 07:41:00 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.9..@fluentui/foundation-legacy_v8.2.10)

### Patches

- Bump @fluentui/style-utilities to v8.7.2 ([PR #23848](https://github.com/microsoft/fluentui/pull/23848) by beachball)
- Bump @fluentui/utilities to v8.9.0 ([PR #23848](https://github.com/microsoft/fluentui/pull/23848) by beachball)

## [8.2.9](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.9)

Tue, 28 Jun 2022 07:39:04 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.8..@fluentui/foundation-legacy_v8.2.9)

### Patches

- Bump @fluentui/style-utilities to v8.7.1 ([PR #23683](https://github.com/microsoft/fluentui/pull/23683) by beachball)

## [8.2.8](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.8)

Tue, 07 Jun 2022 07:48:04 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.7..@fluentui/foundation-legacy_v8.2.8)

### Patches

- Bump @fluentui/style-utilities to v8.7.0 ([PR #23266](https://github.com/microsoft/fluentui/pull/23266) by beachball)

## [8.2.7](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.7)

Fri, 13 May 2022 07:45:35 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.6..@fluentui/foundation-legacy_v8.2.7)

### Patches

- Bump @fluentui/merge-styles to v8.5.2 ([PR #22966](https://github.com/microsoft/fluentui/pull/22966) by beachball)
- Bump @fluentui/set-version to v8.2.1 ([PR #22966](https://github.com/microsoft/fluentui/pull/22966) by beachball)
- Bump @fluentui/style-utilities to v8.6.7 ([PR #22966](https://github.com/microsoft/fluentui/pull/22966) by beachball)
- Bump @fluentui/utilities to v8.8.3 ([PR #22966](https://github.com/microsoft/fluentui/pull/22966) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.19 ([PR #22966](https://github.com/microsoft/fluentui/pull/22966) by beachball)

## [8.2.6](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.6)

Fri, 15 Apr 2022 07:42:48 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.5..@fluentui/foundation-legacy_v8.2.6)

### Patches

- Bump @fluentui/merge-styles to v8.5.1 ([PR #22499](https://github.com/microsoft/fluentui/pull/22499) by beachball)
- Bump @fluentui/style-utilities to v8.6.6 ([PR #22499](https://github.com/microsoft/fluentui/pull/22499) by beachball)
- Bump @fluentui/utilities to v8.8.2 ([PR #22499](https://github.com/microsoft/fluentui/pull/22499) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.18 ([PR #22499](https://github.com/microsoft/fluentui/pull/22499) by beachball)

## [8.2.5](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.5)

Tue, 15 Mar 2022 07:45:54 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.4..@fluentui/foundation-legacy_v8.2.5)

### Patches

- Bump @fluentui/style-utilities to v8.6.5 ([PR #22094](https://github.com/microsoft/fluentui/pull/22094) by beachball)
- Bump @fluentui/utilities to v8.8.1 ([PR #22094](https://github.com/microsoft/fluentui/pull/22094) by beachball)

## [8.2.4](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.4)

Fri, 11 Mar 2022 07:34:41 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.3..@fluentui/foundation-legacy_v8.2.4)

### Patches

- Bump @fluentui/merge-styles to v8.5.0 ([PR #22047](https://github.com/microsoft/fluentui/pull/22047) by beachball)
- Bump @fluentui/style-utilities to v8.6.4 ([PR #22047](https://github.com/microsoft/fluentui/pull/22047) by beachball)
- Bump @fluentui/utilities to v8.8.0 ([PR #22047](https://github.com/microsoft/fluentui/pull/22047) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.17 ([PR #22047](https://github.com/microsoft/fluentui/pull/22047) by beachball)

## [8.2.3](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.3)

Thu, 10 Mar 2022 07:34:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.2..@fluentui/foundation-legacy_v8.2.3)

### Patches

- Bump @fluentui/style-utilities to v8.6.3 ([PR #22043](https://github.com/microsoft/fluentui/pull/22043) by beachball)

## [8.2.2](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.2)

Wed, 09 Mar 2022 07:37:30 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.1..@fluentui/foundation-legacy_v8.2.2)

### Patches

- Bump @fluentui/style-utilities to v8.6.2 ([PR #22008](https://github.com/microsoft/fluentui/pull/22008) by beachball)
- Bump @fluentui/utilities to v8.7.0 ([PR #22008](https://github.com/microsoft/fluentui/pull/22008) by beachball)

## [8.2.1](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.1)

Tue, 08 Mar 2022 23:29:58 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.2.0..@fluentui/foundation-legacy_v8.2.1)

### Patches

- Bump @fluentui/style-utilities to v8.6.1 ([PR #22006](https://github.com/microsoft/fluentui/pull/22006) by beachball)

## [8.2.0](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.2.0)

Thu, 03 Mar 2022 07:24:26 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.25..@fluentui/foundation-legacy_v8.2.0)

### Minor changes

- Adding explicit export maps on all consumer packages for FUIR 8 and 9. ([PR #21508](https://github.com/microsoft/fluentui/pull/21508) by dzearing@microsoft.com)
- Bump @fluentui/merge-styles to v8.4.0 ([PR #21919](https://github.com/microsoft/fluentui/pull/21919) by beachball)
- Bump @fluentui/set-version to v8.2.0 ([PR #21919](https://github.com/microsoft/fluentui/pull/21919) by beachball)
- Bump @fluentui/style-utilities to v8.6.0 ([PR #21919](https://github.com/microsoft/fluentui/pull/21919) by beachball)
- Bump @fluentui/utilities to v8.6.0 ([PR #21919](https://github.com/microsoft/fluentui/pull/21919) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.16 ([PR #21919](https://github.com/microsoft/fluentui/pull/21919) by beachball)

## [8.1.25](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.25)

Tue, 01 Mar 2022 07:23:43 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.24..@fluentui/foundation-legacy_v8.1.25)

### Patches

- Bump @fluentui/style-utilities to v8.5.8 ([PR #21852](https://github.com/microsoft/fluentui/pull/21852) by beachball)
- Bump @fluentui/utilities to v8.5.0 ([PR #21852](https://github.com/microsoft/fluentui/pull/21852) by beachball)

## [8.1.24](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.24)

Thu, 24 Feb 2022 07:29:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.23..@fluentui/foundation-legacy_v8.1.24)

### Patches

- Bump @fluentui/style-utilities to v8.5.7 ([PR #21837](https://github.com/microsoft/fluentui/pull/21837) by beachball)
- Bump @fluentui/utilities to v8.4.3 ([PR #21837](https://github.com/microsoft/fluentui/pull/21837) by beachball)

## [8.1.23](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.23)

Thu, 17 Feb 2022 07:28:31 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.22..@fluentui/foundation-legacy_v8.1.23)

### Patches

- Bump @fluentui/style-utilities to v8.5.6 ([PR #21777](https://github.com/microsoft/fluentui/pull/21777) by beachball)
- Bump @fluentui/utilities to v8.4.2 ([PR #21777](https://github.com/microsoft/fluentui/pull/21777) by beachball)

## [8.1.22](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.22)

Fri, 11 Feb 2022 07:27:49 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.21..@fluentui/foundation-legacy_v8.1.22)

### Patches

- Bump @fluentui/style-utilities to v8.5.5 ([PR #21706](https://github.com/microsoft/fluentui/pull/21706) by beachball)
- Bump @fluentui/utilities to v8.4.1 ([PR #21706](https://github.com/microsoft/fluentui/pull/21706) by beachball)

## [8.1.21](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.21)

Wed, 09 Feb 2022 07:30:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.20..@fluentui/foundation-legacy_v8.1.21)

### Patches

- Bump @fluentui/style-utilities to v8.5.4 ([PR #21603](https://github.com/microsoft/fluentui/pull/21603) by beachball)
- Bump @fluentui/utilities to v8.4.0 ([PR #21603](https://github.com/microsoft/fluentui/pull/21603) by beachball)

## [8.1.20](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.20)

Thu, 03 Feb 2022 07:29:41 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.19..@fluentui/foundation-legacy_v8.1.20)

### Patches

- Bump @fluentui/merge-styles to v8.3.0 ([PR #21545](https://github.com/microsoft/fluentui/pull/21545) by beachball)
- Bump @fluentui/style-utilities to v8.5.3 ([PR #21545](https://github.com/microsoft/fluentui/pull/21545) by beachball)
- Bump @fluentui/utilities to v8.3.10 ([PR #21545](https://github.com/microsoft/fluentui/pull/21545) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.15 ([PR #21545](https://github.com/microsoft/fluentui/pull/21545) by beachball)

## [8.1.19](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.19)

Mon, 03 Jan 2022 23:32:11 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.18..@fluentui/foundation-legacy_v8.1.19)

### Patches

- Bump @fluentui/merge-styles to v8.2.3 ([PR #20954](https://github.com/microsoft/fluentui/pull/20954) by beachball)
- Bump @fluentui/style-utilities to v8.5.2 ([PR #20954](https://github.com/microsoft/fluentui/pull/20954) by beachball)
- Bump @fluentui/utilities to v8.3.9 ([PR #20954](https://github.com/microsoft/fluentui/pull/20954) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.14 ([PR #20954](https://github.com/microsoft/fluentui/pull/20954) by beachball)

## [8.1.18](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.18)

Wed, 15 Dec 2021 07:31:29 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.17..@fluentui/foundation-legacy_v8.1.18)

### Patches

- Bump @fluentui/style-utilities to v8.5.1 ([PR #20716](https://github.com/microsoft/fluentui/pull/20716) by beachball)
- Bump @fluentui/utilities to v8.3.8 ([PR #20716](https://github.com/microsoft/fluentui/pull/20716) by beachball)

## [8.1.17](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.17)

Thu, 25 Nov 2021 14:54:16 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.16..@fluentui/foundation-legacy_v8.1.17)

### Patches

- Bump @fluentui/merge-styles to v8.2.2 ([PR #20784](https://github.com/microsoft/fluentui/pull/20784) by beachball)
- Bump @fluentui/set-version to v8.1.5 ([PR #20784](https://github.com/microsoft/fluentui/pull/20784) by beachball)
- Bump @fluentui/style-utilities to v8.5.0 ([PR #20784](https://github.com/microsoft/fluentui/pull/20784) by beachball)
- Bump @fluentui/utilities to v8.3.7 ([PR #20784](https://github.com/microsoft/fluentui/pull/20784) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.13 ([PR #20784](https://github.com/microsoft/fluentui/pull/20784) by beachball)

## [8.1.16](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.16)

Wed, 10 Nov 2021 07:31:59 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.15..@fluentui/foundation-legacy_v8.1.16)

### Patches

- Bump @fluentui/merge-styles to v8.2.1 ([PR #20529](https://github.com/microsoft/fluentui/pull/20529) by beachball)
- Bump @fluentui/style-utilities to v8.4.2 ([PR #20529](https://github.com/microsoft/fluentui/pull/20529) by beachball)
- Bump @fluentui/utilities to v8.3.6 ([PR #20529](https://github.com/microsoft/fluentui/pull/20529) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.12 ([PR #20529](https://github.com/microsoft/fluentui/pull/20529) by beachball)

## [8.1.15](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.15)

Tue, 02 Nov 2021 07:37:02 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.14..@fluentui/foundation-legacy_v8.1.15)

### Patches

- Bump @fluentui/style-utilities to v8.4.1 ([PR #20331](https://github.com/microsoft/fluentui/pull/20331) by beachball)
- Bump @fluentui/utilities to v8.3.5 ([PR #20331](https://github.com/microsoft/fluentui/pull/20331) by beachball)

## [8.1.14](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.14)

Mon, 01 Nov 2021 07:32:08 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.13..@fluentui/foundation-legacy_v8.1.14)

### Patches

- Bump @fluentui/style-utilities to v8.4.0 ([PR #20231](https://github.com/microsoft/fluentui/pull/20231) by beachball)

## [8.1.13](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.13)

Tue, 05 Oct 2021 07:37:17 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.12..@fluentui/foundation-legacy_v8.1.13)

### Patches

- Bump @fluentui/style-utilities to v8.3.4 ([PR #20105](https://github.com/microsoft/fluentui/pull/20105) by beachball)
- Bump @fluentui/utilities to v8.3.4 ([PR #20105](https://github.com/microsoft/fluentui/pull/20105) by beachball)

## [8.1.12](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.12)

Tue, 28 Sep 2021 22:17:07 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.11..@fluentui/foundation-legacy_v8.1.12)

### Patches

- Bump @fluentui/merge-styles to v8.2.0 ([PR #20000](https://github.com/microsoft/fluentui/pull/20000) by beachball)
- Bump @fluentui/style-utilities to v8.3.3 ([PR #20000](https://github.com/microsoft/fluentui/pull/20000) by beachball)
- Bump @fluentui/utilities to v8.3.3 ([PR #20000](https://github.com/microsoft/fluentui/pull/20000) by beachball)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.11 ([PR #20000](https://github.com/microsoft/fluentui/pull/20000) by beachball)

## [8.1.11](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.11)

Thu, 02 Sep 2021 07:36:46 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.10..@fluentui/foundation-legacy_v8.1.11)

### Patches

- Bump @fluentui/utilities to v8.3.2 ([PR #19542](https://github.com/microsoft/fluentui/pull/19542) by xiaowxie@microsoft.com)

## [8.1.10](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.10)

Wed, 25 Aug 2021 07:35:19 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.9..@fluentui/foundation-legacy_v8.1.10)

### Patches

- Bump @fluentui/merge-styles to v8.1.5 ([PR #19481](https://github.com/microsoft/fluentui/pull/19481) by arujain@microsoft.com)

## [8.1.9](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.9)

Thu, 19 Aug 2021 07:41:35 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.8..@fluentui/foundation-legacy_v8.1.9)

### Patches

- Bump @fluentui/style-utilities to v8.3.0 ([PR #19416](https://github.com/microsoft/fluentui/pull/19416) by dzearing@hotmail.com)

## [8.1.8](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.8)

Tue, 03 Aug 2021 07:39:30 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.7..@fluentui/foundation-legacy_v8.1.8)

### Patches

- Bump @fluentui/utilities to v8.2.2 ([PR #19169](https://github.com/microsoft/fluentui/pull/19169) by behowell@microsoft.com)

## [8.1.7](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.7)

Thu, 29 Jul 2021 07:35:37 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.6..@fluentui/foundation-legacy_v8.1.7)

### Patches

- Bump @fluentui/style-utilities to v8.2.1 ([PR #18028](https://github.com/microsoft/fluentui/pull/18028) by ashwin.gokhale98@gmail.com)

## [8.1.6](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.6)

Tue, 13 Jul 2021 07:35:36 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.5..@fluentui/foundation-legacy_v8.1.6)

### Patches

- Bump @fluentui/style-utilities to v8.2.0 ([PR #18802](https://github.com/microsoft/fluentui/pull/18802) by tmichon@microsoft.com)

## [8.1.5](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.5)

Fri, 09 Jul 2021 07:39:31 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.4..@fluentui/foundation-legacy_v8.1.5)

### Patches

- Bump @fluentui/utilities to v8.2.1 ([PR #18808](https://github.com/microsoft/fluentui/pull/18808) by martinhochel@microsoft.com)

## [8.1.4](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.4)

Mon, 28 Jun 2021 07:35:16 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.3..@fluentui/foundation-legacy_v8.1.4)

### Patches

- Bump @fluentui/utilities to v8.2.0 ([PR #18556](https://github.com/microsoft/fluentui/pull/18556) by jamwu@microsoft.com)

## [8.1.3](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.3)

Tue, 15 Jun 2021 07:40:20 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.2..@fluentui/foundation-legacy_v8.1.3)

### Patches

- Bump @fluentui/style-utilities to v8.1.3 ([PR #18249](https://github.com/microsoft/fluentui/pull/18249) by sarah.higley@microsoft.com)

## [8.1.2](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.2)

Mon, 07 Jun 2021 07:38:15 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.1..@fluentui/foundation-legacy_v8.1.2)

### Patches

- Bump @fluentui/utilities to v8.1.2 ([PR #18437](https://github.com/microsoft/fluentui/pull/18437) by martinhochel@microsoft.com)

## [8.1.1](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.1)

Thu, 20 May 2021 07:41:54 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.1.0..@fluentui/foundation-legacy_v8.1.1)

### Patches

- Mark old ThemeProvider as deprecated to avoid confusion ([PR #18024](https://github.com/microsoft/fluentui/pull/18024) by elcraig@microsoft.com)

## [8.1.0](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.1.0)

Fri, 30 Apr 2021 07:42:23 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.5..@fluentui/foundation-legacy_v8.1.0)

### Minor changes

- Upgrade to typescript 4.1.5 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)

### Patches

- Bump @fluentui/utilities to v8.1.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/style-utilities to v8.1.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/eslint-plugin to v1.2.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/jest-serializer-merge-styles to v8.0.5 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/merge-styles to v8.1.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/set-version to v8.1.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)
- Bump @fluentui/scripts to v1.0.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)

## [8.0.5](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.5)

Fri, 23 Apr 2021 07:37:10 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.4..@fluentui/foundation-legacy_v8.0.5)

### Patches

- Bump @fluentui/utilities to v8.0.5 ([PR #17894](https://github.com/microsoft/fluentui/pull/17894) by olfedias@microsoft.com)

## [8.0.4](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.4)

Tue, 13 Apr 2021 14:55:56 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.3..@fluentui/foundation-legacy_v8.0.4)

### Patches

- Bump @fluentui/utilities to v8.0.4 ([PR #17716](https://github.com/microsoft/fluentui/pull/17716) by jaredi@microsoft.com)

## [8.0.3](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.3)

Wed, 31 Mar 2021 00:53:43 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.2..@fluentui/foundation-legacy_v8.0.3)

### Patches

- Bump @fluentui/eslint-plugin to v1.1.0 ([PR #17568](https://github.com/microsoft/fluentui/pull/17568) by elcraig@microsoft.com)

## [8.0.2](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.2)

Wed, 03 Mar 2021 00:10:09 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.1..@fluentui/foundation-legacy_v8.0.2)

### Patches

- Fix webpack bundle ([PR #17246](https://github.com/microsoft/fluentui/pull/17246) by elcraig@microsoft.com)

## [8.0.1](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.1)

Fri, 26 Feb 2021 01:16:27 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.19..@fluentui/foundation-legacy_v8.0.1)

### Patches

- Release version 8 ([PR #17169](https://github.com/microsoft/fluentui/pull/17169) by elcraig@microsoft.com)

## [8.0.0-beta.19](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.19)

Mon, 22 Feb 2021 12:26:22 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.18..@fluentui/foundation-legacy_v8.0.0-beta.19)

### Changes

- Bump @fluentui/jest-serializer-merge-styles to v8.0.0-beta.7 ([PR #17061](https://github.com/microsoft/fluentui/pull/17061) by elcraig@microsoft.com)

## [8.0.0-beta.18](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.18)

Thu, 18 Feb 2021 19:38:50 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.17..@fluentui/foundation-legacy_v8.0.0-beta.18)

### Changes

- Allow React 17 in peerDependencies. The library has not yet been fully validated with React 17, so please report any issues you find. ([PR #17048](https://github.com/microsoft/fluentui/pull/17048) by elcraig@microsoft.com)

## [8.0.0-beta.17](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.17)

Thu, 18 Feb 2021 12:27:34 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.16..@fluentui/foundation-legacy_v8.0.0-beta.17)

### Changes

- Bump @fluentui/utilities to v8.0.0-beta.13 ([PR #16975](https://github.com/microsoft/fluentui/pull/16975) by elcraig@microsoft.com)

## [8.0.0-beta.16](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.16)

Mon, 15 Feb 2021 12:22:00 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.15..@fluentui/foundation-legacy_v8.0.0-beta.16)

### Changes

- Bump @fluentui/utilities to v8.0.0-beta.12 ([PR #16880](https://github.com/microsoft/fluentui/pull/16880) by xgao@microsoft.com)

## [8.0.0-beta.15](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.15)

Fri, 12 Feb 2021 12:26:20 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.14..@fluentui/foundation-legacy_v8.0.0-beta.15)

### Changes

- Bump @fluentui/style-utilities to v8.0.0-beta.15 ([PR #16935](https://github.com/microsoft/fluentui/pull/16935) by xgao@microsoft.com)

## [8.0.0-beta.14](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.14)

Thu, 11 Feb 2021 00:58:10 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.13..@fluentui/foundation-legacy_v8.0.0-beta.14)

### Changes

- Bump @fluentui/utilities to v8.0.0-beta.11 ([PR #16911](https://github.com/microsoft/fluentui/pull/16911) by xgao@microsoft.com)

## [8.0.0-beta.12](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.12)

Thu, 21 Jan 2021 12:36:12 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.4..@fluentui/foundation-legacy_v8.0.0-beta.12)

### Changes

-  Updating dev dependencies. ([PR #16548](https://github.com/microsoft/fluentui/pull/16548) by dzearing@microsoft.com)

## [8.0.0-beta.4](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.4)

Mon, 02 Nov 2020 12:32:47 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/foundation-legacy_v8.0.0-beta.0..@fluentui/foundation-legacy_v8.0.0-beta.4)

### Changes

- Add deprecation note to readme ([PR #15790](https://github.com/microsoft/fluentui/pull/15790) by elcraig@microsoft.com)

## [8.0.0-beta.0](https://github.com/microsoft/fluentui/tree/@fluentui/foundation-legacy_v8.0.0-beta.0)

Fri, 23 Oct 2020 03:26:15 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.9.8..@fluentui/foundation-legacy_v8.0.0-beta.0)

### Changes

- rename @uifabric/foundation to @fluentui/foundation-legacy ([PR #15595](https://github.com/microsoft/fluentui/pull/15595) by xgao@microsoft.com)
- Rename @uifabric/set-version to @fluentui/set-version ([PR #15616](https://github.com/microsoft/fluentui/pull/15616) by ololubek@microsoft.com)
- Rename @uifabric/merge-styles to @fluentui/merge-styles ([PR #15627](https://github.com/microsoft/fluentui/pull/15627) by ololubek@microsoft.com)
- Rename @uifabric/react-hooks to @fluentui/react-hooks & @uifabric/utilities to @fluentui/utilities ([PR #15629](https://github.com/microsoft/fluentui/pull/15629) by ololubek@microsoft.com)
- Remove react-dom from peerDependencies ([PR #15634](https://github.com/microsoft/fluentui/pull/15634) by elcraig@microsoft.com)
- Rename @uifabric/styling to @fluentui/style-utilities ([PR #15567](https://github.com/microsoft/fluentui/pull/15567) by elcraig@microsoft.com)

## [7.9.8](https://github.com/microsoft/fluentui/tree/@uifabric/foundation_v7.9.8)

Fri, 25 Sep 2020 12:25:17 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.9.2..@uifabric/foundation_v7.9.8)

### Patches

- Using getResolveAlias for webpack config. ([PR #15132](https://github.com/microsoft/fluentui/pull/15132) by humbertomakotomorimoto@gmail.com)

## [7.8.1](https://github.com/microsoft/fluentui/tree/@uifabric/foundation_v7.8.1)

Thu, 20 Aug 2020 12:37:22 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.7.38..@uifabric/foundation_v7.8.1)

### Patches

- Remove references to React global (add explicit imports) ([PR #14613](https://github.com/microsoft/fluentui/pull/14613) by elcraig@microsoft.com)

## [7.7.38](https://github.com/microsoft/fluentui/tree/@uifabric/foundation_v7.7.38)

Tue, 21 Jul 2020 12:43:08 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.7.35..@uifabric/foundation_v7.7.38)

### Patches

- Fix "rules of hooks" lint rule violations ([PR #14097](https://github.com/microsoft/fluentui/pull/14097) by elcraig@microsoft.com)

## [7.7.10](https://github.com/microsoft/fluentui/tree/@uifabric/foundation_v7.7.10)

Thu, 07 May 2020 01:06:55 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.7.0..@uifabric/foundation_v7.7.10)

### Patches

- Addressing commonjs imports. ([PR #13031](https://github.com/microsoft/fluentui/pull/13031) by dzearing@microsoft.com)

## [7.7.0](https://github.com/microsoft/fluentui/tree/@uifabric/foundation_v7.7.0)

Thu, 16 Apr 2020 04:01:45 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@uifabric/foundation_v7.5.25..@uifabric/foundation_v7.7.0)

### Minor changes

- Fixing rtl customizer scenarios in Foundation components. ([PR #12649](https://github.com/microsoft/fluentui/pull/12649) by humbertomakotomorimoto@gmail.com)

### Patches

- Readme: Fabric=>Fluent wording updates ([PR #12508](https://github.com/microsoft/fluentui/pull/12508) by elcraig@microsoft.com)

## 7.5.23
Wed, 25 Mar 2020 12:30:04 GMT

### Patches

- Changing references of Fabric to Fluent (mgodbolt@microsoft.com)
## 7.5.22
Mon, 23 Mar 2020 12:28:29 GMT

### Patches

- Replace OfficeDev/office-ui-fabric-react with microsoft/fluentui (elcraig@microsoft.com)
## 7.5.2
Fri, 17 Jan 2020 02:32:17 GMT

### Patches

- Update tslib minver to first version containing __spreadArrays helper due to changes in how TS emits spreads. (jagore@microsoft.com)
## 7.5.1
Thu, 16 Jan 2020 12:28:58 GMT

### Patches

- Upgrade repo to TS3.7. (jagore@microsoft.com)
## 7.5.0
Thu, 07 Nov 2019 12:26:32 GMT

### Minor changes

- Deprecate IPropsWithChildren type that is redundant with React.PropsWithChildren. (jagore@microsoft.com)
## 7.4.4
Thu, 03 Oct 2019 23:14:46 GMT

### Patches

- Fixing a publishing issue with foundation (odbuild@microsoft.com)
- Fixes broken publish (odbuild@microsoft.com)
## 7.4.2
Thu, 03 Oct 2019 01:14:35 GMT

### Patches

- Foundation next requires @uifabric/merge-styles dependency (KevinTCoughlin@users.noreply.github.com)
## 7.4.1
Thu, 12 Sep 2019 12:34:15 GMT

### Patches

- Enable api-extractor, and minor import fixes to prevent api-extractor errors (elcraig@microsoft.com)
## 7.4.0
Fri, 06 Sep 2019 12:34:51 GMT

### Minor changes

- Foundation: Allowing recomposition in composed. (humbertomakotomorimoto@gmail.com)
## 7.3.1
Wed, 04 Sep 2019 04:09:58 GMT

### Patches

- fix version file (kchau@microsoft.com)
## 7.3.0
Mon, 02 Sep 2019 12:33:56 GMT

### Minor changes

- Foundation: Moving slots inside composed options. (humbertomakotomorimoto@gmail.com)
## 7.2.0
Thu, 29 Aug 2019 12:30:00 GMT

### Minor changes

- Renaming createComponent to compose and moving View inside component options object. (humbertomakotomorimoto@gmail.com)
## 7.1.0
Mon, 26 Aug 2019 12:30:49 GMT

### Minor changes

- Memoizing styling in createComponent for components that have their default styling determined entirely by tokens. (Humberto.Morimoto@microsoft.com)
## 7.0.4
Fri, 23 Aug 2019 12:35:28 GMT

### Patches

- Update npmignores, delete unused jest setup files (elcraig@microsoft.com)
- Fix up readme and package.json descriptions (elcraig@microsoft.com)

## 7.0.3
Wed, 17 Jul 2019 18:58:57 GMT

### Patches

- Adding @types/react and @types/react-dom to package.json that have peer dependencies on react and react-dom. (makotom@microsoft.com)

## 7.0.2
Mon, 01 Jul 2019 18:51:42 GMT

### Patches

- adds react-app-polyfill

## 7.0.1
Fri, 14 Jun 2019 15:54:00 GMT

### Patches

- Major bumping the foundation package. (Though the tooling will report this as a patch.)

## 0.109.2
Fri, 14 Jun 2019 12:26:30 GMT

### Patches

- Fix missing assets in production build.

## 0.109.1
Thu, 13 Jun 2019 00:24:48 GMT

### Patches

- Initial release of Fabric 7

## 0.8.0
Wed, 12 Jun 2019 00:42:26 GMT

### Minor changes

- Updating IComponent typings for ease of use in tests.
- Evolve create component API to separate out view and make options bag optional.
- Enable API verification and export legacy styled.
- Foundation: Convert state components to hooks.
- Slots: Move slot options from individual props to new slots prop object.
- Slots: Refactor API and add slot options object.

### Patches

- Update and dedupe React deps.

## 0.7.7
Tue, 11 Jun 2019 12:21:35 GMT

### Patches

- upgrade to api-extractor 7.1.6

## 0.7.6
Tue, 14 May 2019 07:50:30 GMT

### Patches

- Update Fabric assets link

## 0.7.5
Thu, 09 May 2019 12:35:50 GMT

### Patches

- Remove duplicate export from foundation package.

## 0.7.4
Tue, 02 Apr 2019 00:38:14 GMT

### Patches

- Use ^ ranges instead of >=

## 0.7.3
Mon, 01 Apr 2019 12:37:03 GMT

### Patches

- Passing styling and tokens to view.

## 0.7.2
Fri, 15 Mar 2019 12:34:06 GMT

### Patches

- TSDoc fixes.

## 0.7.1
Mon, 04 Feb 2019 13:36:12 GMT

### Patches

- Optimize React hierarchy by naming Unknowns and removing view layers.

## 0.7.0
Thu, 31 Jan 2019 20:10:48 GMT

### Minor changes

- Promote Slots and Tokens implementation of Foundation.

## 0.6.0
Fri, 14 Dec 2018 13:35:30 GMT

### Minor changes

- Add styling and utilities packages as dependencies and remove corresponding type injection.

## 0.5.7
Wed, 31 Oct 2018 12:32:41 GMT

### Patches

- Add theme provider for using schemes. Remove implicit scheme prop for all components using Foundation.

## 0.5.6
Thu, 18 Oct 2018 20:22:36 GMT

### Patches

- Remove api-extractor.disabled.json

## 0.5.5
Mon, 08 Oct 2018 12:24:15 GMT

### Patches

- Moving tslint/prettier dependencies

## 0.5.4
Tue, 02 Oct 2018 12:28:04 GMT

### Patches

- Interface refactoring for reducing dev friction.

## 0.5.3
Fri, 21 Sep 2018 14:25:46 GMT

### Patches

- Adding a version stamp file
- Support schemes through new schemes prop.

## 0.5.2
Mon, 17 Sep 2018 12:27:05 GMT

### Patches

- Refactor Foundation to remove code duplication, ease props typing, and make option parameter definition more consistent.

## 0.5.1
Mon, 10 Sep 2018 10:24:57 GMT

### Patches

- Remove Object.assign usage to fix IE11 issues.

## 0.5.0
Fri, 07 Sep 2018 22:04:50 GMT

### Minor changes

- Adjusting foundation usage, using new React 16 context.

## 0.4.1
Wed, 29 Aug 2018 10:28:42 GMT

### Patches

- Remove Object.assign usage to fix IE11 issues.

## 0.4.0
Fri, 24 Aug 2018 17:02:14 GMT

### Minor changes

- Reverting Customizer React 16 context change.

## 0.3.0
Thu, 23 Aug 2018 10:28:17 GMT

### Minor changes

- Adjusting foundation usage, using new React 16 context.

## 0.2.5
Tue, 14 Aug 2018 10:27:33 GMT

### Patches

- disabling codepen task

## 0.2.4
Fri, 10 Aug 2018 10:26:09 GMT

### Patches

- Add support for contextual theming and styling.

## 0.2.3
Wed, 08 Aug 2018 10:25:08 GMT

### Patches

- Align createComponent naming with React terminology.

## 0.2.2
Fri, 03 Aug 2018 10:25:59 GMT

### Patches

- Add tslib as dependency.

## 0.2.1
Thu, 02 Aug 2018 10:23:19 GMT

### Patches

- Add webpack config.

## 0.2.0
Wed, 01 Aug 2018 10:25:51 GMT

### Minor changes

- Major improvements to typing and functionality.

## 0.1.0
Mon, 23 Jul 2018 10:28:08 GMT

### Minor changes

- Addressing bad imports.

## 0.0.3
Mon, 09 Jul 2018 18:08:32 GMT

### Patches

- Improve typing consistency.
