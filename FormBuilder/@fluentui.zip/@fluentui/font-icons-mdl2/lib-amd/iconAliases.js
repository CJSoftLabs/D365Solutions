define(["require", "exports", "@fluentui/style-utilities"], function (require, exports, style_utilities_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.registerIconAliases = void 0;
    var registerIconAliases = function () {
        (0, style_utilities_1.registerIconAlias)('trash', 'delete');
        (0, style_utilities_1.registerIconAlias)('onedrive', 'onedrivelogo');
        (0, style_utilities_1.registerIconAlias)('alertsolid12', 'eventdatemissed12');
        (0, style_utilities_1.registerIconAlias)('sixpointstar', '6pointstar');
        (0, style_utilities_1.registerIconAlias)('twelvepointstar', '12pointstar');
        (0, style_utilities_1.registerIconAlias)('toggleon', 'toggleleft');
        (0, style_utilities_1.registerIconAlias)('toggleoff', 'toggleright');
    };
    exports.registerIconAliases = registerIconAliases;
    exports.default = exports.registerIconAliases;
});
//# sourceMappingURL=iconAliases.js.map