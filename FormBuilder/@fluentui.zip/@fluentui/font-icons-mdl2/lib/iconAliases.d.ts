export declare const registerIconAliases: () => void;
export default registerIconAliases;
