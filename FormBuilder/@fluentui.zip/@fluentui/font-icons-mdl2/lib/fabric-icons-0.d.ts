import { IIconOptions } from '@fluentui/style-utilities';
export declare function initializeIcons(baseUrl?: string, options?: IIconOptions): void;
