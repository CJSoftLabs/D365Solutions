import { IIconOptions } from '@fluentui/style-utilities';
declare global {
    interface Window {
        /**
         * The FabricConfig options can be burned on the page prior to script load to provide
         * alternative defaults at script load time. This helps avoid race conditions by calling
         * `initializeIcons` too late, or in cases where you can't control the `initializeIcons` call,
         * such as using the pre-created Fluent bundle.
         */
        FabricConfig?: {
            /**
             * Controls the base url of the font files. This is useful for scenarios where the fonts
             * are stored on a private CDN other than the default SharePoint CDN.
             */
            fontBaseUrl?: string;
            /**
             * Controls the base url of the icon font files. This is useful for scenarios where the icons
             * are stored on a private CDN other than the default SharePoint CDN. Note that in prior
             * iterations, `fontBaseUrl` was used to control both font and icon base urls. While you can
             * still use `fontBaseUrl` to provide a single base url for both, the `iconBaseUrl` will be
             * used first if available.
             */
            iconBaseUrl?: string;
        };
    }
}
export declare function initializeIcons(baseUrl?: string, options?: IIconOptions): void;
export type { IconNamesInput } from './IconNames';
export { IconNames } from './IconNames';
import './version';
